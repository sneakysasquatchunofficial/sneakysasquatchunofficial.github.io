#!/bin/sh
# Builds "SSMod Studio.app" into the SSMod folder (it starts studio/server.py and shows the editor).
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
[ -f "$HERE/icon.png" ] || ~/ssvenv/bin/python3 "$HERE/make_icon.py"
bash ~/.claude/skills/mac-app/make_app.sh --swift "$HERE/app/main.swift" --name "SSMod Studio" --icon "$HERE/icon.png" --out "$(dirname "$HERE")"
