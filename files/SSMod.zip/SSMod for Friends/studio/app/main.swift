// SSMod Studio.app: starts studio/server.py (with the SSMod Python, ~/ssvenv) and shows the editor in a window.
// Built by studio/build_app.sh. The app sits in the SSMod folder and finds studio/server.py next to itself.
import Cocoa
import WebKit

let port = 8765
let home = FileManager.default.homeDirectoryForCurrentUser

func ssmodFolder() -> URL {
    let next = Bundle.main.bundleURL.deletingLastPathComponent()
    if FileManager.default.fileExists(atPath: next.appendingPathComponent("studio/server.py").path) { return next }
    return home.appendingPathComponent("Downloads/SSMod")
}

class AppDelegate: NSObject, NSApplicationDelegate, WKUIDelegate {
    var win: NSWindow!
    var web: WKWebView!
    var server: Process?

    func applicationDidFinishLaunching(_ n: Notification) {
        let cfg = WKWebViewConfiguration()
        cfg.preferences.setValue(true, forKey: "developerExtrasEnabled")
        web = WKWebView(frame: .zero, configuration: cfg)
        web.uiDelegate = self
        web.loadHTMLString("<body style='background:#1e2027;color:#8b91a0;font:13px -apple-system;display:flex;align-items:center;justify-content:center;height:90vh'>Starting SSMod Studio…</body>", baseURL: nil)
        win = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1440, height: 900),
                       styleMask: [.titled, .closable, .miniaturizable, .resizable], backing: .buffered, defer: false)
        win.title = "SSMod Studio"
        win.minSize = NSSize(width: 900, height: 560)
        win.contentView = web
        win.center()
        win.setFrameAutosaveName("SSModStudioWindow")
        win.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        startServer()
    }

    func startServer() {
        let url = URL(string: "http://127.0.0.1:\(port)/api/projects")!
        URLSession.shared.dataTask(with: url) { _, resp, _ in
            DispatchQueue.main.async {
                if (resp as? HTTPURLResponse)?.statusCode != 200 { self.launch() }
                self.waitForServer(tries: 0)
            }
        }.resume()
    }

    func launch() {
        let folder = ssmodFolder()
        let p = Process()
        p.executableURL = home.appendingPathComponent("ssvenv/bin/python3")
        p.arguments = [folder.appendingPathComponent("studio/server.py").path, "--port", String(port)]
        p.currentDirectoryURL = folder
        let logURL = folder.appendingPathComponent("studio/server.log")
        FileManager.default.createFile(atPath: logURL.path, contents: nil)
        if let fh = try? FileHandle(forWritingTo: logURL) { p.standardOutput = fh; p.standardError = fh }
        do { try p.run(); server = p } catch { showError("Couldn't start the Studio server: \(error.localizedDescription)") }
    }

    func waitForServer(tries: Int) {
        let url = URL(string: "http://127.0.0.1:\(port)/api/projects")!
        URLSession.shared.dataTask(with: url) { _, resp, _ in
            DispatchQueue.main.async {
                if (resp as? HTTPURLResponse)?.statusCode == 200 {
                    self.web.load(URLRequest(url: URL(string: "http://127.0.0.1:\(port)/")!))
                } else if tries < 100 {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { self.waitForServer(tries: tries + 1) }
                } else {
                    self.showError("The Studio server didn't start. See studio/server.log in the SSMod folder.")
                }
            }
        }.resume()
    }

    func showError(_ msg: String) {
        let a = NSAlert(); a.messageText = "SSMod Studio"; a.informativeText = msg; a.runModal()
    }

    func webView(_ w: WKWebView, runJavaScriptAlertPanelWithMessage m: String, initiatedByFrame f: WKFrameInfo, completionHandler done: @escaping () -> Void) {
        let a = NSAlert(); a.messageText = m; a.runModal(); done()
    }

    func webView(_ w: WKWebView, runJavaScriptConfirmPanelWithMessage m: String, initiatedByFrame f: WKFrameInfo, completionHandler done: @escaping (Bool) -> Void) {
        let a = NSAlert(); a.messageText = m; a.addButton(withTitle: "OK"); a.addButton(withTitle: "Cancel")
        done(a.runModal() == .alertFirstButtonReturn)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ s: NSApplication) -> Bool { true }

    func applicationWillTerminate(_ n: Notification) { server?.terminate() }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.regular)
let menu = NSMenu()
let appItem = NSMenuItem(); menu.addItem(appItem)
let appMenu = NSMenu()
appMenu.addItem(withTitle: "Quit SSMod Studio", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
appItem.submenu = appMenu
let editItem = NSMenuItem(); menu.addItem(editItem)
let editMenu = NSMenu(title: "Edit")              // no Undo here: the page does its own undo (⌘Z)
for (t, s, k) in [("Cut", "cut:", "x"), ("Copy", "copy:", "c"), ("Paste", "paste:", "v"), ("Select All", "selectAll:", "a")] {
    editMenu.addItem(withTitle: t, action: Selector(s), keyEquivalent: k)
}
editItem.submenu = editMenu
app.mainMenu = menu
app.run()
