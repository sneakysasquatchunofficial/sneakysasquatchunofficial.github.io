"""SSMod Studio's back end: a small web server on this Mac only (127.0.0.1) that the editor page talks to.

It reads and saves the .ssmod files, draws the game's scenes as pictures (tools/preview.py) and runs ./ssmod
check / install for the editor. Nothing here touches the game until Install is pressed.

  ~/ssvenv/bin/python3 studio/server.py [--port 8765]          then open http://127.0.0.1:8765/
"""
import json
import os
import shutil
import re
import subprocess
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

STUDIO = os.path.dirname(os.path.abspath(__file__))
HOME = os.path.dirname(STUDIO)
sys.path.insert(0, HOME)
sys.path.insert(0, os.path.join(HOME, "tools"))
CACHE = os.path.join(STUDIO, "cache")
SCENE_PX = 4096                      # the biggest side of a scene picture
PY = sys.executable

_lock = threading.Lock()             # one UnityPy job at a time (it isn't thread safe)
_scene_names = None
_where = {}


def studio_project(path):
    with open(path, encoding="utf-8", errors="replace") as f:
        return f.readline().startswith("// SSMod Studio project")


def profiles():
    """{"": mods folder, "chaos": ...}: the main copy and every profile in ssmod.json."""
    with open(os.path.join(HOME, "ssmod.json")) as fh:
        cfg = json.load(fh)
    out = {"": {"mods": "mods", "game": cfg.get("game", "")}}
    for name, p in cfg.get("profiles", {}).items():
        out[name] = {"mods": p.get("mods", "mods_" + name), "game": p.get("game", "")}
    for p in out.values():
        p["exists"] = os.path.isdir(os.path.expanduser(p["game"]))
    return out


def inside(rel):
    """An absolute path inside the SSMod folder, or None (the page can't read or write anything else)."""
    p = os.path.realpath(os.path.join(HOME, rel))
    return p if p == HOME or p.startswith(HOME + os.sep) else None


def scene_names():
    global _scene_names
    if _scene_names is None:
        import UnityPy
        from ssmodlang.config import game_data
        clean = os.path.join(HOME, "base", "globalgamemanagers")       # without the areas mods added
        env = UnityPy.load(clean if os.path.exists(clean) else os.path.join(game_data(), "globalgamemanagers"))
        f = list(env.files.values())[0]
        bs = next(o for o in f.objects.values() if o.type.name == "BuildSettings").read_typetree()
        _scene_names = {}
        for i, p in enumerate(bs["scenes"]):
            _scene_names.setdefault(os.path.splitext(os.path.basename(p))[0], f"level{i}")
    return _scene_names


def scene_picture(name):
    """{"url", "box": [x0, y0, x1, y1], "w", "h"} of the clean game scene, drawn once and kept in studio/cache."""
    os.makedirs(CACHE, exist_ok=True)
    key = re.sub(r"[^A-Za-z0-9_-]+", "_", name)
    png, meta = os.path.join(CACHE, key + ".png"), os.path.join(CACHE, key + ".json")
    if not os.path.exists(meta):
        with _lock:
            levels = scene_names()
            if name not in levels:
                return None
            import preview
            clean = os.path.join(HOME, "base", levels[name])        # the scene without any mod
            box = preview.render(levels[name], png, scale=0.5, grid=0, robust=True, max_px=SCENE_PX,
                                 src=clean if os.path.exists(clean) else None)
            from PIL import Image
            w, h = Image.open(png).size
            with open(meta, "w") as fh:
                json.dump({"box": list(box), "w": w, "h": h}, fh)
    with open(meta) as fh:
        out = json.load(fh)
    out["url"] = "/cache/" + key + ".png"
    return out


def prop_picture(scene, name):
    """A copied game object drawn on its own: {"url", "rel": [x0, y0, x1, y1] around its origin} (studio/cache)."""
    os.makedirs(CACHE, exist_ok=True)
    key = "prop_" + re.sub(r"[^A-Za-z0-9_-]+", "_", scene + "__" + name)[:150]
    png, meta = os.path.join(CACHE, key + ".png"), os.path.join(CACHE, key + ".json")
    if not os.path.exists(meta):
        with _lock:
            import math
            import preview
            import propsheet
            from PIL import Image
            from ssmodlang.game import SceneCtx, transform_of, world_position
            env, f = propsheet.scene_file(scene)
            go = SceneCtx.find_in(SceneCtx.__new__(SceneCtx), f, name, scene, None, None)
            ds = propsheet.draws_of(f, go)
            b = propsheet.bounds(ds, f)
            info = {"rel": None}
            if b:
                x0, y0, x1, y1 = b
                ox, oy, _ = world_position(f, transform_of(f, f.objects[go].read()).path_id)
                sc = min(1.0, 1024 / max(x1 - x0, y1 - y0, 1))
                img = Image.new("RGBA", (math.ceil((x1 - x0) * sc) + 2, math.ceil((y1 - y0) * sc) + 2), (0, 0, 0, 0))
                ds.sort(key=lambda d: d[0])
                for d in ds:
                    to_px = lambda x, y: ((x - x0) * sc + 1, (y1 - y) * sc + 1)
                    if d[2] == "SpriteRenderer":
                        preview.draw_sprite(img, d[3], d[4], to_px, sc)
                    else:
                        preview.draw_mesh(img, d[3], d[4], d[5], f.objects, to_px, d[7])
                img.save(png)
                info["rel"] = [x0 - ox - 1 / sc, y0 - oy - 1 / sc, x1 - ox + 1 / sc, y1 - oy + 1 / sc]
            with open(meta, "w") as fh:
                json.dump(info, fh)
    with open(meta) as fh:
        out = json.load(fh)
    if out.get("rel"):
        out["url"] = "/cache/" + key + ".png"
    return out


def where(name):
    """Named objects of a scene with positions ([name, x, y]), from ./ssmod where (they can be used as positions)."""
    if name not in _where:
        r = subprocess.run([os.path.join(HOME, "ssmod"), "where", name], cwd=HOME, capture_output=True, text=True)
        rows = []
        for line in r.stdout.splitlines():
            m = re.match(r"\s+(.*?)\s+\(\s*(-?\d+(?:\.\d+)?),\s*(-?\d+(?:\.\d+)?)\)\s*$", line)
            if m:
                rows.append([m.group(1), float(m.group(2)), float(m.group(3))])
        _where[name] = rows
    return _where[name]


def run_ssmod(profile, args):
    env = dict(os.environ)
    if profile:
        env["SSMOD_PROFILE"] = profile
    env["NO_COLOR"] = "1"
    r = subprocess.run([os.path.join(HOME, "ssmod")] + args, cwd=HOME, env=env, capture_output=True, text=True)
    return {"ok": r.returncode == 0, "out": (r.stdout + r.stderr)[-20000:]}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, body, kind="application/json", code=200):
        if not isinstance(body, bytes):
            body = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", kind)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def file(self, path):
        if not path or not os.path.isfile(path):
            return self.send({"error": "not found"}, code=404)
        ext = os.path.splitext(path)[1].lower()
        kind = {".html": "text/html; charset=utf-8", ".png": "image/png", ".jpg": "image/jpeg",
                ".js": "text/javascript", ".css": "text/css"}.get(ext, "text/plain; charset=utf-8")
        with open(path, "rb") as fh:
            self.send(fh.read(), kind)

    def do_GET(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        try:
            if u.path in ("/", "/index.html"):
                return self.file(os.path.join(STUDIO, "index.html"))
            if u.path.startswith("/cache/"):
                return self.file(os.path.join(CACHE, os.path.basename(u.path)))
            if u.path == "/api/projects":
                out = []
                for name, p in profiles().items():
                    folder = inside(p["mods"])
                    mods = sorted(f for f in os.listdir(folder) if f.endswith(".ssmod")) if folder and os.path.isdir(folder) else []
                    if q.get("all") != "1":                   # the Studio only shows projects made in it
                        mods = [f for f in mods if studio_project(os.path.join(folder, f))]
                    out.append({"profile": name, "mods": p["mods"], "files": mods, "game": p["game"], "exists": p["exists"]})
                return self.send(out)
            if u.path == "/api/trails":                   # TrailN door names already used in a scene, by any mod
                folder = inside(profiles().get(q.get("profile", ""), {}).get("mods", "mods"))
                pat = re.compile(r'connect\s+\w+\s+to\s+"' + re.escape(q.get("scene", "")) + r'"\s+Trail(\d+)')
                used = set()
                for f in os.listdir(folder) if folder and os.path.isdir(folder) else []:
                    if f.endswith(".ssmod"):
                        used.update(int(n) for n in pat.findall(open(os.path.join(folder, f), encoding="utf-8", errors="replace").read()))
                return self.send(sorted(used))
            if u.path == "/api/file":
                return self.file(inside(q.get("path", "")))
            if u.path == "/api/scenes":
                return self.send(sorted(scene_names(), key=str.lower))
            if u.path == "/api/scene":
                pic = scene_picture(q.get("name", ""))
                return self.send(pic or {"error": "not a game scene"}, code=200 if pic else 404)
            if u.path == "/api/prop":
                return self.send(prop_picture(q.get("scene", ""), q.get("name", "")))
            if u.path == "/api/where":
                return self.send(where(q.get("name", "")))
            if u.path == "/api/art":
                folder = inside(q.get("dir", "mods"))
                out = []
                for root, dirs, files in os.walk(folder or HOME):
                    dirs[:] = [d for d in dirs if d not in ("disabled", "__pycache__")]
                    for f in files:
                        if f.lower().endswith((".png", ".jpg")):
                            out.append(os.path.relpath(os.path.join(root, f), folder))
                return self.send(sorted(out)[:3000])
            return self.send({"error": "unknown"}, code=404)
        except Exception as e:          # the page shows it in the console
            return self.send({"error": f"{type(e).__name__}: {e}"}, code=500)

    def do_POST(self):
        u = urlparse(self.path)
        n = int(self.headers.get("Content-Length") or 0)
        body = json.loads(self.rfile.read(n) or b"{}")
        try:
            if u.path == "/api/save":
                path = inside(body["path"])
                if not path or not path.endswith(".ssmod"):
                    return self.send({"error": "only .ssmod files in the SSMod folder"}, code=400)
                made_here = body["text"].startswith("// SSMod Studio project") and (not os.path.exists(path) or studio_project(path))
                if not made_here:
                    return self.send({"error": "SSMod's own mods can't be changed here"}, code=403)
                with open(path, "w") as fh:
                    fh.write(body["text"])
                return self.send({"ok": True})
            if u.path == "/api/check":
                path = inside(body["path"])
                return self.send(run_ssmod(body.get("profile", ""), ["check", path]))
            if u.path == "/api/install":
                return self.send(run_ssmod(body.get("profile", ""), ["install"]))
            if u.path == "/api/new":
                name = re.sub(r'["\\]', "", body.get("name", "")).strip() or "My Mod"
                prof = body.get("profile", "")
                r = run_ssmod(prof, ["new", name, body.get("kind", "npc")])
                return self.send(r)
            if u.path == "/api/test":                     # only this project, in a copy of its own
                if "test" not in profiles():
                    return self.send({"error": "There's no test copy yet"}, code=400)
                src = inside(body["path"])
                folder = inside(profiles()["test"]["mods"])
                os.makedirs(folder, exist_ok=True)
                for f in os.listdir(folder):
                    if f.endswith(".ssmod"):
                        os.remove(os.path.join(folder, f))
                shutil.copy(src, folder)
                r = run_ssmod("test", ["install"])
                if r.get("ok"):
                    subprocess.run(["open", os.path.expanduser(profiles()["test"]["game"])])
                return self.send(r)
            if u.path == "/api/publish":                  # compile first, then put a copy where it's easy to share
                src = inside(body["path"])
                r = run_ssmod(body.get("profile", ""), ["check", src])
                if not r.get("ok"):
                    return self.send(r)
                out = os.path.join(HOME, "published")
                os.makedirs(out, exist_ok=True)
                shutil.copy(src, out)
                subprocess.run(["open", out])
                r["published"] = os.path.join("published", os.path.basename(src))
                return self.send(r)
            if u.path == "/api/play":
                game = os.path.expanduser(profiles()[body.get("profile", "")]["game"])
                if not os.path.isdir(game):
                    return self.send({"ok": False, "out": f"no game copy at {game}"})
                subprocess.Popen(["open", game])
                return self.send({"ok": True, "out": "opened " + os.path.basename(game)})
            return self.send({"error": "unknown"}, code=404)
        except Exception as e:
            return self.send({"error": f"{type(e).__name__}: {e}"}, code=500)


def main():
    port = 8765
    if "--port" in sys.argv:
        port = int(sys.argv[sys.argv.index("--port") + 1])
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"SSMod Studio on http://127.0.0.1:{port}/", flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
