"""studio/icon.png: a flat green footprint on a dark tile (in the game's flat style)."""
import os
from PIL import Image, ImageDraw

S = 1024
img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
d.rounded_rectangle([60, 60, S - 60, S - 60], 200, fill="#262932")
d.rounded_rectangle([60, 640, S - 60, S - 60], 200, fill="#1E2027")
d.rectangle([60, 640, S - 60, 760], fill="#1E2027")
d.rectangle([60, 600, S - 60, 640], fill="#262932")
G, GD = "#71A352", "#5A8A3F"
d.ellipse([330, 360, 690, 820], fill=GD)                     # the sole, darker side first
d.ellipse([310, 350, 670, 800], fill=G)
d.ellipse([400, 700, 640, 860], fill=G)                      # the heel
for x, y, r in [(300, 300, 62), (410, 220, 70), (530, 200, 72), (640, 240, 64), (720, 330, 54)]:
    d.ellipse([x - r + 10, y - r + 10, x + r + 10, y + r + 10], fill=GD)
    d.ellipse([x - r, y - r, x + r, y + r], fill=G)
img.save(os.path.join(os.path.dirname(os.path.abspath(__file__)), "icon.png"))
