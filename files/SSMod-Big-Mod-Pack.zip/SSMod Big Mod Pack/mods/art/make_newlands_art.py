"""Art for Sasquatch: New Lands (mods/new_lands.ssmod), in the same lit style as the trails (paint.py): cottages, the
well, the Great Lantern (dark and lit), lantern posts, the ferry, crates, barrels, driftwood, the bakery, bunting and
the ruins of the Old Woods. 1 pixel = 1 world unit, 14 units of room under each picture's ground point.
  ~/ssvenv/bin/python3 mods/art/make_newlands_art.py
"""
import math
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paint import Art, np, rgb  # noqa: E402

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "newlands")
WOOD, WOOD_DARK, WOOD_LIGHT = "#B07C48", "#80582F", "#D0A06A"
STONE, STONE_DARK = "#A3A1A8", "#7D7B86"


def save(a, name):
    a.save(os.path.join(OUT, name + ".png"))


def shade(c, k):
    r, g, b = rgb(c)
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(v * k))) for v in (r, g, b))


def glow(a, cx, cy, r, colour="#FFD98A", strength=0.55):
    """A soft halo of light (drawn last, over everything)."""
    g = a.grid(cx - r, cy - r, cx + r, cy + r)
    X, Y, box = g
    d = np.sqrt((X - cx) ** 2 + (Y - cy) ** 2) / r
    alpha = np.clip(1 - d, 0, 1) ** 2 * strength
    a.put(box, np.broadcast_to(np.array(rgb(colour), np.float32), X.shape + (3,)).copy(), alpha)


def window(a, x, y, w, h, lit):
    a.poly([(x - w / 2 - 5, y - 5), (x + w / 2 + 5, y - 5), (x + w / 2 + 5, y + h + 5), (x - w / 2 - 5, y + h + 5)],
           "#F2EEE4", tex=0.04)
    a.poly([(x - w / 2, y), (x + w / 2, y), (x + w / 2, y + h), (x - w / 2, y + h)], "#FFE08A" if lit else "#4F6D86",
           tex=0.02, grad=0.4)
    a.line([(x, y), (x, y + h)], "#F2EEE4", 3)
    a.line([(x - w / 2, y + h / 2), (x + w / 2, y + h / 2)], "#F2EEE4", 3)


def cottage(name, wall, roof, door, seed):
    """A timber cottage with a steep roof, a chimney, two windows and a door with a step."""
    rnd = random.Random(seed)
    a = Art(420, 400, seed=seed)
    a.shadow(10, 4, 200, 24)
    a.poly([(-170, 0), (170, 0), (170, 180), (-170, 180)], wall, tex=0.12, grad=0.18, normal=(0, 0, 1))
    for x in (-170, -60, 60, 170):                       # timber frame
        a.poly([(x - 7, 0), (x + 7, 0), (x + 7, 180), (x - 7, 180)], "#6E4A2C", tex=0.15)
    a.poly([(-170, 86), (170, 86), (170, 98), (-170, 98)], "#6E4A2C", tex=0.15)
    a.poly([(-176, 0), (176, 0), (176, 16), (-176, 16)], STONE_DARK, tex=0.2)
    window(a, -115, 106, 64, 56, True)
    window(a, 115, 106, 64, 56, True)
    a.poly([(-34, 0), (34, 0), (34, 120), (0, 140), (-34, 120)], door, tex=0.12, normal=(0, 0, 1))
    a.ball(22, 62, 4, 4, "#FFD166", tex=0, spec=0.6)
    a.poly([(-46, -6), (46, -6), (40, 4), (-40, 4)], STONE, tex=0.1)
    a.cylinder(80, 230, 116, 340, "#8C5A4A", tex=0.2, top="#5E3A30")      # chimney
    a.poly([(-205, 170), (205, 170), (0, 345)], roof, tex=0.1, normal=(0, 0.6, 1))
    a.poly([(0, 345), (205, 170), (150, 170)], shade(roof, 0.75), tex=0.1)
    for k in range(1, 6):                               # shingle rows
        y = 170 + k * 29
        half = 205 * (1 - (y - 170) / 175)
        a.line([(-half, y), (half, y)], shade(roof, 0.8), 2)
    a.poly([(-212, 164), (212, 164), (212, 174), (-212, 174)], shade(roof, 0.6), tex=0.05)
    for _ in range(5):                                  # flower box under the windows
        for x0 in (-115, 115):
            a.ball(x0 + rnd.uniform(-28, 28), 104 + rnd.uniform(-2, 4), 6, 5, rnd.choice(["#F06C8E", "#FAD14E", "#8678E6"]),
                   tex=0, spec=0.3)
    save(a, name)


def well(name):
    a = Art(220, 250)
    a.shadow(0, 2, 100, 18)
    a.cylinder(-80, 0, 80, 70, STONE, tex=0.25, top="#3B4A5A")
    for row in range(3):
        a.line([(-78, 22 + row * 22), (78, 22 + row * 22)], STONE_DARK, 2)
    for x in (-70, 70):
        a.cylinder(x - 7, 60, x + 7, 190, WOOD_DARK, bark=True)
    a.poly([(-96, 180), (96, 180), (0, 240)], "#9B4A3A", tex=0.1, normal=(0, 0.6, 1))
    a.line([(-70, 168), (70, 168)], WOOD, 6)
    a.line([(0, 168), (0, 120)], "#C9B28A", 2)
    a.cylinder(-12, 96, 12, 122, WOOD, tex=0.1, top=WOOD_LIGHT)
    save(a, name)


def great_lantern(name, lit):
    a = Art(260, 560)
    a.shadow(0, 2, 90, 16)
    a.cylinder(-50, 0, 50, 40, STONE, tex=0.2, top=STONE)
    a.cylinder(-14, 40, 14, 380, "#3E3F48", tex=0.04)
    for y in (120, 260):
        a.cylinder(-20, y, 20, y + 12, "#5A5B66", tex=0)
    a.poly([(-70, 380), (70, 380), (60, 400), (-60, 400)], "#3E3F48", tex=0.03)
    glass = "#FFD66B" if lit else "#4A5866"
    a.poly([(-62, 400), (62, 400), (78, 500), (-78, 500)], glass, tex=0.02, grad=0.3)
    for x in (-40, 0, 40):
        a.line([(x * 1.0, 400), (x * 1.25, 500)], "#3E3F48", 4)
    if lit:
        for x, c in ((-34, "#79C8FF"), (0, "#8DF5A0"), (34, "#FF8FC8")):     # the three glow stones inside
            a.ball(x, 440, 13, 15, c, tex=0, spec=0.7, rim=0.1)
    else:
        for x in (-34, 0, 34):                                              # empty sockets
            a.ball(x, 440, 11, 12, "#2E3640", tex=0, spec=0.1, rim=0.3)
    a.poly([(-92, 500), (92, 500), (0, 560)], "#3E3F48", tex=0.05, normal=(0, 0.6, 1))
    a.ball(0, 562, 9, 9, "#C9A227", tex=0, spec=0.6)
    if lit:
        glow(a, 0, 450, 130, "#FFE9A0", 0.6)
    save(a, name)


def lamp_post(name, lit=True):
    a = Art(80, 230)
    a.shadow(0, 2, 22, 6)
    a.cylinder(-5, 0, 5, 180, "#3E3F48", tex=0.03)
    a.line([(0, 176), (22, 188)], "#3E3F48", 4)
    a.poly([(10, 150), (34, 150), (38, 186), (6, 186)], "#FFD66B" if lit else "#4A5866", tex=0, grad=0.3)
    a.poly([(4, 186), (40, 186), (22, 200)], "#3E3F48", tex=0)
    if lit:
        glow(a, 22, 168, 38, "#FFE9A0", 0.5)
    save(a, name)


def crate(name, seed):
    a = Art(100, 100, seed=seed)
    a.shadow(4, 2, 50, 9)
    a.poly([(-42, 0), (42, 0), (42, 70), (-42, 70)], WOOD, tex=0.2, normal=(0, 0, 1))
    a.poly([(-42, 70), (42, 70), (30, 88), (-30, 88)], WOOD_LIGHT, tex=0.15, normal=(0, 1, 0.4))
    a.line([(-38, 4), (38, 66)], WOOD_DARK, 4)
    a.line([(-38, 66), (38, 4)], WOOD_DARK, 4)
    for x in (-42, 42):
        a.line([(x, 0), (x, 70)], WOOD_DARK, 3)
    save(a, name)


def barrel(name):
    a = Art(80, 100)
    a.shadow(4, 2, 38, 8)
    a.cylinder(-30, 0, 30, 80, "#9A6A3E", bark=True, top="#7A5230")
    for y in (14, 66):
        a.cylinder(-31, y, 31, y + 6, "#55565E", tex=0)
    save(a, name)


def driftwood(name):
    a = Art(200, 50, below=8)
    a.shadow(0, 2, 90, 8)
    a.line([(-80, 12), (-20, 18), (40, 14), (82, 22)], "#B9A891", 16)
    a.line([(-20, 18), (-40, 34)], "#B9A891", 7)
    a.line([(40, 14), (56, 30)], "#A99880", 6)
    save(a, name)


def ferry(name):
    """The ferry: a little white boat with a red stripe, a cabin and a lamp. Seen side-on, bow to the right."""
    a = Art(620, 330)
    hull = [(-280, 70), (250, 70), (300, 140), (-300, 140)]
    a.poly([(-270, 40), (240, 40), (300, 140), (-300, 140)], "#F2F0EA", tex=0.04, grad=0.3, normal=(0, -0.3, 1))
    a.poly([(-270, 40), (240, 40), (250, 60), (-280, 60)], "#2F4858", tex=0.04)
    a.poly([(-292, 110), (282, 110), (292, 126), (-298, 126)], "#C8352E", tex=0.04)
    a.poly([(-300, 140), (300, 140), (300, 152), (-300, 152)], WOOD_LIGHT, tex=0.1)
    a.poly([(-170, 152), (60, 152), (60, 262), (-170, 262)], "#F7F5EE", tex=0.04, normal=(0, 0, 1))
    for x in (-130, -60, 10):
        a.poly([(x, 196), (x + 44, 196), (x + 44, 236), (x, 236)], "#7FA7C2", tex=0, grad=0.4)
    a.poly([(-186, 262), (76, 262), (60, 286), (-170, 286)], "#2F4858", tex=0.05, normal=(0, 0.8, 1))
    a.cylinder(-110, 286, -94, 320, "#C8352E", tex=0, top="#2F4858")
    a.ball(150, 175, 16, 16, "#F2C14E", tex=0, spec=0.3)      # a life ring
    a.ball(150, 175, 7, 7, "#F2F0EA", tex=0, spec=0, rim=0)
    a.text("FERNBROOK FERRY", -60, 82, 22, "#2F4858", engrave=False)
    save(a, name)


def bunting(name, w):
    """A string of little flags hung between two posts (stands on the left post's foot)."""
    rnd = random.Random(w)
    a = Art(w + 40, 260)
    for x in (-w / 2, w / 2):
        a.cylinder(x - 6, 0, x + 6, 240, WOOD_DARK, bark=True, top=WOOD_LIGHT)
    pts = [(-w / 2 + w * t / 20, 230 - math.sin(math.pi * t / 20) * 50) for t in range(21)]
    a.line(pts, "#6B6B6B", 2)
    for (x0, y0), (x1, y1) in zip(pts[::2], pts[1::2]):
        c = rnd.choice(["#E63946", "#F4A261", "#2A9D8F", "#E9C46A", "#8678E6", "#F06C8E"])
        a.poly([(x0, y0), (x1, y1), ((x0 + x1) / 2, (y0 + y1) / 2 - 30)], c, tex=0.03, grad=0.3)
    save(a, name)


def bakery(name):
    a = Art(440, 330)
    a.shadow(0, 2, 210, 22)
    for x in (-190, 190):
        a.cylinder(x - 8, 0, x + 8, 270, WOOD_DARK, bark=True)
    a.poly([(-180, 0), (180, 0), (180, 90), (-180, 90)], "#E8D8BC", tex=0.1, normal=(0, -0.2, 1))
    a.poly([(-190, 90), (190, 90), (196, 106), (-196, 106)], WOOD_LIGHT, tex=0.08, normal=(0, 1, 0.4))
    a.poly([(-120, 30), (120, 30), (120, 76), (-120, 76)], WOOD, tex=0.14, normal=(0, 0, 1))
    a.text("BAKERY", 0, 53, 28, "#5B3A29")
    for x in (-150, -105, 110, 152):                     # loaves
        a.ball(x, 118, 22, 12, "#C9873E", tex=0.06, spec=0.3)
        a.line([(x - 10, 122), (x - 4, 126)], "#E8C08A", 2)
        a.line([(x + 2, 122), (x + 8, 126)], "#E8C08A", 2)
    for k in range(10):
        x0 = -210 + k * 42
        c = "#2A9D8F" if k % 2 == 0 else "#F7F3EA"
        a.poly([(x0, 250), (x0 + 42, 250), (x0 + 38, 312), (x0 + 4, 312)], c, tex=0.05, grad=0.4, normal=(0, 0.6, 1))
        a.poly([(x0 + 21 + 21 * math.cos(t), 250 - 13 * math.sin(t)) for t in [math.pi * k / 12 for k in range(13)]],
               c, tex=0.03, grad=0.5)                  # the scalloped edge
    save(a, name)


def ruin_arch(name):
    a = Art(380, 340)
    a.shadow(0, 2, 180, 20)
    for x in (-130, 130):
        a.poly([(x - 34, 0), (x + 34, 0), (x + 30, 230), (x - 30, 230)], STONE, tex=0.25, grad=0.2, normal=(0, 0, 1))
        for y in range(30, 230, 40):
            a.line([(x - 32, y), (x + 32, y)], STONE_DARK, 2)
    pts_out = [(-160 + 320 * t / 16, 230 + math.sin(math.pi * t / 16) * 90) for t in range(17)]
    pts_in = [(-100 + 200 * t / 16, 230 + math.sin(math.pi * t / 16) * 50) for t in range(17)]
    a.poly(pts_out + pts_in[::-1], STONE, tex=0.25, grad=0.2, normal=(0, 0.2, 1))
    a.poly([(60, 300), (90, 290), (100, 316), (70, 320)], "#C9C7CE", tex=0)     # a chipped bit
    rnd = random.Random(4)
    for _ in range(16):                                   # ivy
        t = rnd.random()
        x, y = pts_out[int(t * 16)]
        a.ball(x + rnd.uniform(-10, 10), y - rnd.uniform(0, 30), 10, 8, rnd.choice(["#5E9E48", "#4E8A3E"]), tex=0.1, spec=0.1)
    for _ in range(8):
        x = rnd.choice((-130, 130)) + rnd.uniform(-30, 30)
        a.ball(x, rnd.uniform(20, 200), 9, 8, "#4E8A3E", tex=0.1, spec=0.1)
    save(a, name)


def pillar(name, h):
    a = Art(120, h + 20)
    a.shadow(0, 2, 56, 10)
    a.cylinder(-34, 0, 34, h, STONE, tex=0.22, top="#BDBBC2")
    for x in (-18, 0, 18):
        a.line([(x, 6), (x, h - 4)], STONE_DARK, 2)
    a.ball(-20, h * 0.6, 14, 10, "#5E9E48", tex=0.2, spec=0)
    save(a, name)


def glow_shrooms(name):
    """A ring of glowing blue mushrooms (the woods at night)."""
    rnd = random.Random(9)
    a = Art(160, 70, below=8)
    for _ in range(9):
        x = rnd.uniform(-64, 64)
        h = rnd.uniform(10, 26)
        a.cylinder(x - 2, 0, x + 2, h, "#E6F2F7", tex=0)
        a.ball(x, h, rnd.uniform(6, 10), 5, "#5FC8E8", tex=0, spec=0.6)
    glow(a, 0, 20, 70, "#9BE6FF", 0.35)
    save(a, name)


def glow_stone(name, colour, seed):
    """A Glow Stone: a little cluster of lit crystals with a halo."""
    rnd = random.Random(seed)
    a = Art(110, 100, below=8, seed=seed)
    a.shadow(0, 2, 34, 7)
    for x, h, w in sorted([(rnd.uniform(-22, 22), rnd.uniform(34, 62), rnd.uniform(10, 16)) for _ in range(5)], key=lambda t: -t[1]):
        tip = (x + rnd.uniform(-6, 6), h)
        a.poly([(x - w, 0), (x - w * 0.8, h * 0.7), tip, (x, 0)], shade(colour, 1.15), tex=0.02, grad=0.5)
        a.poly([(x, 0), tip, (x + w * 0.8, h * 0.7), (x + w, 0)], shade(colour, 0.8), tex=0.02, grad=0.5)
    glow(a, 0, 30, 52, colour, 0.5)
    save(a, name)


def notice(name, words, left=False):
    a = Art(200, 160)
    a.shadow(0, 2, 40, 8)
    a.cylinder(-7, 0, 7, 130, WOOD_DARK, bark=True)
    pts = [(-96, 74), (70, 74), (104, 102), (70, 130), (-96, 130)]
    if left:
        pts = [(-x, y) for x, y in pts]
    a.poly(pts, "#C99A62", tex=0.15, grad=0.3, normal=(0, 0.1, 1))
    a.text(words, 8 if left else -8, 102, 22, "#4A2C17", max_w=160)
    save(a, name)


if __name__ == "__main__":
    cottage("cottage_red", "#EDE3CF", "#B5452F", "#3E6E8E", 1)
    cottage("cottage_blue", "#E4E7EA", "#3E6E8E", "#B5452F", 2)
    cottage("cottage_green", "#F0E6D2", "#4E7D4A", "#8E5A3E", 3)
    cottage("cottage_plum", "#EFE5D8", "#6E4A7E", "#3E6E5E", 4)
    well("well")
    great_lantern("great_lantern_dark", False)
    great_lantern("great_lantern_lit", True)
    lamp_post("lamp_post")
    crate("crate", 1)
    barrel("barrel")
    driftwood("driftwood")
    ferry("ferry")
    bunting("bunting", 600)
    bakery("bakery")
    ruin_arch("ruin_arch")
    pillar("pillar_tall", 220)
    pillar("pillar_short", 110)
    glow_shrooms("glow_shrooms")
    glow_stone("glow_blue", "#79C8FF", 1)
    glow_stone("glow_green", "#8DF5A0", 2)
    glow_stone("glow_pink", "#FF8FC8", 3)
    notice("sign_fernbrook", "FERNBROOK")
    notice("sign_woods", "OLD WOODS")
    notice("sign_landing", "LANDING", left=True)
    notice("sign_newlands", "NEW LANDS", left=True)
    print("pictures in", OUT)
