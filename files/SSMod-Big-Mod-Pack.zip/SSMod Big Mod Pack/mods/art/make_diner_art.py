"""Art for mods/diner.ssmod in the game's flat style. Everything in the diner is drawn here: nothing is copied from
the game except its people.

  ~/ssvenv/bin/python3 mods/art/make_diner_art.py
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import make_tax_art as tax  # noqa: E402
from make_tax_art import Flat, HEDGE, HEDGE_DARK, POT, POT_DARK  # noqa: E402

tax.OUT = os.path.join(HERE, "diner")

WALL = "#E9E2D0"
WALL_DARK = "#D2CAB6"
TEAL = "#3FA7A0"
TEAL_DARK = "#2E837D"
RED = "#D9534F"
RED_DARK = "#B23E3B"
CHROME = "#C9CED6"
CHROME_DARK = "#A3A9B3"
GLASS = "#8FC3D9"
GLASS_DARK = "#74A9C0"
ROOF = "#5A5F6B"
GOLD = "#F2C14E"
DOOR_GAP = 130                      # the game's bank doors (±29.5 each leaf) stand in this


def front():
    """The diner seen from the trail: 760 wide, door in the middle at the bottom."""
    a = Flat(760, 440)
    a.shadow(0, 0, 400, 16)
    a.rect(-380, 0, 380, 300, WALL)                        # the body
    a.rect(-380, 0, 380, 26, WALL_DARK)                    # the skirting
    a.rect(-380, 120, 380, 150, TEAL)                      # the teal band
    a.rect(-380, 120, 380, 128, TEAL_DARK)
    a.rect(-380, 150, 380, 158, CHROME)                    # chrome trim
    a.rect(-380, 112, 380, 120, CHROME_DARK)
    for x0 in (-350, -230, 110, 230):                      # windows either side of the door
        a.rect(x0, 170, x0 + 110, 270, CHROME)
        a.rect(x0 + 6, 176, x0 + 104, 264, GLASS)
        a.rect(x0 + 6, 176, x0 + 104, 196, GLASS_DARK)
    a.rect(-390, 300, 390, 330, ROOF)                      # the roof edge
    a.rect(-390, 300, 390, 308, "#4A4E58")
    a.rect(-DOOR_GAP / 2 - 12, 0, DOOR_GAP / 2 + 12, 236, CHROME)    # the door frame (the game's doors fill it)
    a.rect(-DOOR_GAP / 2, 0, DOOR_GAP / 2, 226, "#3A3F4A")
    for x0 in (-DOOR_GAP / 2 + 6, 3):                        # two glass doors
        a.rect(x0, 6, x0 + DOOR_GAP / 2 - 9, 220, GLASS)
        a.rect(x0, 6, x0 + DOOR_GAP / 2 - 9, 60, GLASS_DARK)
    a.rect(-16, 90, -8, 150, CHROME)
    a.rect(8, 90, 16, 150, CHROME)
    a.rect(-DOOR_GAP / 2 - 12, 226, DOOR_GAP / 2 + 12, 236, CHROME_DARK)
    # the big sign on the roof
    a.rect(-170, 330, 170, 420, RED_DARK)
    a.rect(-164, 336, 164, 420, RED)
    a.rect(-150, 346, 150, 410, "#FFF6E0")
    a.text("BIGFOOT DINER", 0, 378, 30, RED_DARK, max_w=280)
    a.rect(-200, 330, -170, 360, CHROME_DARK)              # sign posts
    a.rect(170, 330, 200, 360, CHROME_DARK)
    a.text("EAT", -290, 220, 22, TEAL_DARK)                 # painted on the left window
    a.save("diner_front")


def floor():
    """The floor inside (1 pixel = 1 world unit, 1600 x 900): a soft checker in the dining room, plain light tiles in
    the kitchen (right of the counter's left end, above the counter), a darker strip under the counter."""
    from PIL import Image, ImageDraw
    w, h, t = 1600, 900, 64
    kx, ky = 1020, 900 - 493                   # the kitchen corner in picture pixels (x -3980, y 1300)
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for i in range(w // t + 1):
        for j in range(h // t + 1):
            d.rectangle([i * t, j * t, i * t + t, j * t + t], fill="#EFE9DD" if (i + j) % 2 else "#9AA3AE")
    d.rectangle([kx, 0, w, ky], fill="#DCDFE2")
    for x in range(kx, w, 48):
        d.line([x, 0, x, ky], fill="#C9CDD2", width=2)
    for y in range(0, ky, 48):
        d.line([kx, y, w, y], fill="#C9CDD2", width=2)
    d.rectangle([kx, ky - 6, w, ky + 6], fill="#7B828C")
    img.save(os.path.join(tax.OUT, "diner_floor.png"))


def menu_board():
    """The menu on the dining room wall: every recipe with what goes in it (made at the prep counter)."""
    a = Flat(380, 300, below=0)
    a.rect(-190, 0, 190, 300, "#4A4E58")
    a.rect(-182, 8, 182, 292, "#2F3238")
    a.text("MENU", 0, 270, 26, GOLD)
    y = 236
    for dish, what in (("BREAKFAST PLATE", "eggs  bacon  bread"), ("PANCAKES", "pancake mix  eggs"),
                       ("CHEESEBURGER", "patty  bread  cheese"), ("FISH TACOS", "fish  taco"),
                       ("LOADED POTATO", "potato  cheese  bacon"), ("HOMEMADE PIZZA", "flour  cheese  steak")):
        a.text(dish, 0, y, 15, "#FFFFFF", max_w=330)
        a.text(what, 0, y - 16, 10.5, "#AEB4BF", max_w=330)
        y -= 39
    a.save("menu_board")


def open_sign():
    a = Flat(120, 60, below=0)
    a.rect(-60, 0, 60, 60, RED_DARK, r=10)
    a.rect(-54, 6, 54, 54, RED, r=8)
    a.text("OPEN", 0, 30, 24, "#FFF6E0")
    a.save("open_sign")


SEAT, SEAT_DARK, TABLE, TABLE_DARK = "#D9534F", "#B23E3B", "#6E7682", "#5A616C"
WOOD, WOOD_DARK = "#B98A5A", "#94693F"
STEEL, STEEL_DARK = "#CDD2D9", "#A8AEB7"


def booth():
    """A red booth seen from the front: two bench backs and a grey table between them."""
    a = Flat(150, 120)
    a.shadow(0, 0, 74, 9)
    for x in (-58, 58):
        a.rect(x - 16, 0, x + 16, 108, SEAT_DARK, r=6)
        a.rect(x - 16, 34, x + 16, 108, SEAT, r=6)
    a.rect(-40, 0, 40, 70, TABLE_DARK)
    a.rect(-44, 62, 44, 78, TABLE, r=3)
    a.rect(-16, 78, -8, 92, "#E9C46A")                   # mustard and ketchup
    a.rect(4, 78, 12, 96, SEAT)
    a.save("booth")


def stool():
    a = Flat(44, 62)
    a.shadow(0, 0, 18, 5)
    a.rect(-4, 4, 4, 44, STEEL_DARK)
    a.rect(-14, 0, 14, 7, STEEL)
    a.rect(-19, 42, 19, 60, SEAT_DARK, r=8)
    a.rect(-19, 48, 19, 60, SEAT, r=8)
    a.save("stool")


def counter():
    a = Flat(490, 104)
    a.shadow(0, 0, 244, 9)
    a.rect(-240, 0, 240, 68, TEAL_DARK)
    a.rect(-240, 22, 240, 68, TEAL)
    a.rect(-246, 66, 246, 90, TABLE, r=5)
    a.rect(-246, 66, 246, 74, TABLE_DARK)
    a.rect(-200, 90, -176, 96, "#FFFFFF")                # plates, sauces and a till
    a.rect(-60, 90, -36, 96, "#FFFFFF")
    a.rect(90, 90, 114, 96, "#FFFFFF")
    a.rect(-120, 90, -112, 104, "#E9C46A")
    a.rect(-106, 90, -98, 104, SEAT)
    a.rect(170, 90, 214, 104, "#5A5F6B")
    a.save("counter")


def stove():
    a = Flat(100, 120)
    a.shadow(0, 0, 50, 7)
    a.rect(-46, 0, 46, 104, STEEL)
    a.rect(-46, 0, 46, 14, STEEL_DARK)
    a.rect(-34, 22, 34, 64, "#3A3F4A")                   # the oven
    a.rect(-34, 66, 34, 72, STEEL_DARK)
    a.rect(-46, 104, 46, 116, "#3A3F4A")
    for x in (-24, 24):
        a.rect(x - 15, 110, x + 15, 116, "#23262D")
    for x in (-30, -10, 10, 30):
        a.circle(x, 88, 5, "#5A5F6B")
    a.save("stove")


def fridge():
    a = Flat(100, 170)
    a.shadow(0, 0, 50, 7)
    a.rect(-44, 0, 44, 164, "#EDEFF2", r=8)
    a.rect(-44, 0, 44, 10, STEEL_DARK)
    a.rect(-44, 104, 44, 108, STEEL_DARK)
    a.rect(30, 60, 36, 96, STEEL_DARK)
    a.rect(30, 116, 36, 146, STEEL_DARK)
    a.save("fridge")


def sink():
    a = Flat(100, 120)
    a.shadow(0, 0, 50, 7)
    a.rect(-46, 0, 46, 84, WOOD_DARK)
    a.rect(-46, 10, 46, 84, WOOD)
    a.rect(-1, 12, 1, 80, WOOD_DARK)
    a.rect(-50, 84, 50, 96, TABLE)
    a.rect(-28, 90, 28, 96, "#3A3F4A")
    a.rect(-3, 96, 3, 116, STEEL_DARK)
    a.rect(-3, 112, 16, 116, STEEL_DARK)
    a.save("sink")


def cupboard():
    a = Flat(190, 130)
    a.shadow(0, 0, 94, 7)
    a.rect(-90, 0, 90, 84, "#EDEFF2")
    a.rect(-90, 0, 90, 10, STEEL_DARK)
    for x in (-60, 0, 60):
        a.rect(x - 26, 16, x + 26, 78, "#F8F9FA")
        a.rect(x - 3, 44, x + 3, 50, STEEL_DARK)
    a.rect(-94, 84, 94, 96, TABLE)
    a.rect(20, 96, 78, 128, "#5A5F6B")                   # the microwave
    a.rect(26, 102, 60, 122, "#23262D")
    a.rect(64, 102, 72, 122, STEEL)
    a.rect(-72, 96, -24, 102, "#FFFFFF")                 # plates
    a.rect(-68, 102, -28, 108, "#FFFFFF")
    a.save("cupboard")


def plant():
    a = Flat(80, 120)
    a.shadow(0, 0, 30, 6)
    a.rect(-20, 0, 20, 34, POT_DARK)
    a.rect(-20, 10, 20, 34, POT)
    a.circle(0, 72, 34, HEDGE_DARK)
    a.circle(-4, 78, 28, HEDGE)
    a.save("plant")


def bin_():
    a = Flat(50, 60)
    a.shadow(0, 0, 22, 5)
    a.rect(-18, 0, 18, 46, "#5A5F6B")
    a.rect(-18, 16, 18, 46, "#6E7682")
    a.rect(-21, 46, 21, 54, "#4A4E58")
    a.save("bin")


def burger_sign():
    a = Flat(210, 330)
    a.shadow(0, 0, 60, 12)
    a.rect(-9, 0, 9, 150, STEEL_DARK)
    a.rect(-9, 0, -1, 150, STEEL)
    a.rect(-80, 138, 80, 164, "#C9863F", r=12)           # bottom bun
    a.rect(-90, 164, 90, 180, "#6BAA3C", r=6)            # lettuce
    a.rect(-84, 178, 84, 202, "#5A3320", r=8)            # patty
    a.rect(-86, 200, 86, 210, GOLD)                      # cheese
    a.poly([(-30, 202), (30, 202), (0, 182)], GOLD)
    a.rect(-82, 210, 82, 222, SEAT)                      # tomato
    a.rect(-82, 222, 82, 262, "#D79A4B", r=30)           # top bun
    a.rect(-70, 240, 70, 300, "#D79A4B", r=38)
    a.rect(-70, 222, 70, 246, "#C9863F", r=10)
    for x, y in ((-34, 276), (0, 288), (34, 276), (-16, 262), (20, 260)):
        a.rect(x - 6, y - 2, x + 6, y + 2, "#FFF0C9", r=2)
    a.save("burger_sign")


def judges_table():
    a = Flat(260, 90)
    a.shadow(0, 0, 124, 8)
    a.rect(-120, 0, 120, 70, "#2D6A4F")
    a.rect(-120, 12, 120, 70, "#3A8A67")
    a.rect(-124, 68, 124, 80, "#FFFFFF")
    a.text("JUDGES", 0, 40, 22, "#FFFFFF", max_w=200)
    a.save("judges_table")


def wall_board(name, words, bg, fg):
    a = Flat(280, 110, below=0)
    a.rect(-140, 0, 140, 110, "#4A4E58")
    a.rect(-132, 8, 132, 102, bg)
    a.text(words, 0, 55, 34, fg, max_w=240)
    a.save(name)


def trail_sign(name, words):
    """A wooden sign on two posts, for beside a trail."""
    a = Flat(240, 150)
    a.shadow(0, 0, 90, 7)
    for x in (-84, 84):
        a.rect(x - 7, 0, x + 7, 120, WOOD_DARK)
    a.rect(-112, 60, 112, 134, WOOD_DARK, r=6)
    a.rect(-106, 66, 106, 128, WOOD, r=4)
    a.text(words, 0, 97, 24, "#FFF6E0", max_w=190)
    a.save(name)


def door_mat():
    a = Flat(150, 56, below=0)
    a.rect(-75, 0, 75, 56, "#4A4E58", r=6)
    a.rect(-67, 8, 67, 48, "#5A5F6B", r=4)
    a.text("EXIT", 0, 28, 22, "#FFF6E0")
    a.save("door_mat")


def main():
    os.makedirs(tax.OUT, exist_ok=True)
    front()
    floor()
    menu_board()
    open_sign()
    booth()
    stool()
    counter()
    stove()
    fridge()
    sink()
    cupboard()
    plant()
    bin_()
    burger_sign()
    judges_table()
    door_mat()
    wall_board("cookoff_board", "COOK-OFF", "#D9534F", "#FFF6E0")
    trail_sign("sign_diner", "BIGFOOT DINER")
    trail_sign("sign_town", "TOWN")
    print("wrote", sorted(os.listdir(tax.OUT)))


if __name__ == "__main__":
    main()
