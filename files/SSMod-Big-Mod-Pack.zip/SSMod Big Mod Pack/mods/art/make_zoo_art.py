"""Art for the zoo (mods/zoo.ssmod, made by tools/gen_zoo.py), in the lit trail style (paint.py): a lion, a giraffe, a
penguin, an elephant, the zoo fence, the penguin pool, the ticket booth and the animal signs.
1 pixel = 1 world unit, 14 units of room under each picture's ground point (the pool is a flat ground picture).
  ~/ssvenv/bin/python3 mods/art/make_zoo_art.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paint import Art  # noqa: E402

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "zoo")
WOOD, WOOD_DARK, WOOD_LIGHT = "#B07C48", "#80582F", "#D0A06A"


def save(a, name):
    a.save(os.path.join(OUT, name + ".png"))


def eye(a, x, y, r=4):
    a.ball(x, y, r, r, "#1E1A18", tex=0, spec=0.5, rim=0)


def lion():
    """Facing right: tawny body, a big round mane, tail with a tuft."""
    a = Art(260, 200)
    a.shadow(0, 2, 110, 14)
    for x in (-70, -40, 50, 80):                         # legs, back pair first
        a.cylinder(x - 11, 0, x + 11, 70, "#C99A52" if x in (-70, 50) else "#D9AA5E", tex=0.08)
        a.ball(x + 2, 4, 13, 6, "#B98A46", tex=0, spec=0)
    a.line([(-95, 95), (-120, 80), (-128, 110)], "#C99A52", 7)          # tail
    a.ball(-128, 114, 10, 10, "#7A4A22", tex=0.15)
    a.ball(-5, 92, 100, 42, "#DDB062", tex=0.1, spec=0.1)                # body
    a.ball(85, 120, 50, 54, "#9A5A26", tex=0.25, spec=0.05)              # mane
    a.ball(98, 118, 30, 30, "#E2B868", tex=0.06, spec=0.15)              # face
    a.ball(118, 108, 14, 10, "#F0D49A", tex=0, spec=0.1)                 # muzzle
    a.ball(126, 112, 5, 4, "#3A2A22", tex=0, spec=0.4)                   # nose
    eye(a, 102, 128)
    a.ball(78, 150, 8, 8, "#C08A4A", tex=0, spec=0)                      # ears
    save(a, "lion")


def giraffe():
    a = Art(240, 470)
    a.shadow(0, 2, 90, 14)
    for x in (-50, -26, 34, 58):
        a.cylinder(x - 7, 0, x + 7, 200, "#E7C27A" if x in (-50, 34) else "#F1CF86", tex=0.06)
        a.ball(x, 3, 9, 5, "#5A3E2E", tex=0, spec=0)
    a.ball(4, 215, 76, 40, "#F1CF86", tex=0.06, spec=0.1)                # body
    a.poly([(40, 230), (70, 240), (100, 410), (80, 416)], "#F1CF86", tex=0.06, grad=0.2)   # neck
    a.ball(98, 420, 24, 15, "#F1CF86", tex=0.05, spec=0.15)              # head
    a.ball(118, 414, 10, 8, "#E7C27A", tex=0, spec=0.1)
    for x in (88, 100):                                                  # ossicones
        a.cylinder(x - 2, 432, x + 2, 452, "#C9A060", tex=0, top="#5A3E2E")
    eye(a, 104, 424, 3)
    a.line([(-70, 220), (-92, 190)], "#E7C27A", 4)
    a.ball(-94, 186, 5, 7, "#5A3E2E", tex=0, spec=0)
    import random
    rnd = random.Random(3)
    for _ in range(26):                                                  # patches
        x, y = rnd.uniform(-60, 70), rnd.uniform(196, 245)
        a.ball(x, y, 9, 7, "#B57A3C", tex=0.05, spec=0, rim=0.1, flat=0.8)
    for k in range(9):
        y = 250 + k * 18
        x = 58 + (y - 240) * 0.2
        a.ball(x + (k % 2) * 6, y, 6, 6, "#B57A3C", tex=0, spec=0, rim=0.1, flat=0.8)
    save(a, "giraffe")


def penguin():
    a = Art(80, 110)
    a.shadow(0, 2, 26, 6)
    a.ball(-10, 4, 10, 4, "#F2A23A", tex=0, spec=0.2)
    a.ball(10, 4, 10, 4, "#F2A23A", tex=0, spec=0.2)
    a.ball(0, 46, 26, 42, "#24262C", tex=0.04, spec=0.25)                # body
    a.ball(6, 40, 17, 32, "#F4F4F0", tex=0.03, spec=0.2, rim=0.1)        # belly
    a.ball(4, 84, 17, 16, "#24262C", tex=0.03, spec=0.25)                # head
    a.ball(10, 86, 6, 6, "#F4F4F0", tex=0, spec=0, rim=0)
    eye(a, 11, 87, 2.4)
    a.poly([(18, 82), (32, 78), (18, 74)], "#F2A23A", tex=0, grad=0.3)  # beak
    a.ball(-22, 46, 6, 20, "#1A1C22", tex=0.03, spec=0.2)                # flipper
    save(a, "penguin")


def elephant():
    a = Art(380, 260)
    a.shadow(0, 2, 120, 16)
    for x in (-70, -36, 44, 78):
        a.cylinder(x - 17, 0, x + 17, 90, "#8C9098" if x in (-70, 44) else "#9AA0A8", tex=0.12)
        a.ball(x, 4, 18, 6, "#7A7E86", tex=0, spec=0)
    a.ball(0, 128, 112, 66, "#A4AAB2", tex=0.12, spec=0.08)              # body
    a.line([(-108, 140), (-122, 110)], "#9AA0A8", 5)                     # tail
    a.ball(108, 150, 44, 46, "#A4AAB2", tex=0.1, spec=0.1)               # head
    a.line([(140, 140), (158, 100), (160, 60), (172, 44)], "#9AA0A8", 20)  # trunk
    a.ball(172, 44, 10, 9, "#8C9098", tex=0.05, spec=0.05)
    a.poly([(134, 118), (152, 110), (154, 115), (136, 124)], "#F4EEDC", tex=0, grad=0.3)  # tusk
    a.ball(82, 152, 34, 44, "#9097A0", tex=0.12, spec=0.05)              # ear
    eye(a, 124, 164, 4)
    save(a, "elephant")


def fence():
    """One zoo fence panel, 220 wide: posts with green rails and a wire mesh look."""
    a = Art(220, 120, below=10)
    a.shadow(0, 2, 110, 6, alpha=0.25)
    for x in (-104, 0, 104):
        a.cylinder(x - 6, 0, x + 6, 110, "#3E5A40", tex=0.05, top="#5B7C5C")
    for y in (14, 104):
        a.poly([(-110, y), (110, y), (110, y + 8), (-110, y + 8)], "#4E6E50", tex=0.04, grad=0.4)
    for k in range(-21, 22):                                             # mesh
        x = k * 5
        a.line([(x - 10, 22), (x + 10, 104)], "#8A9A8C", 0.8)
        a.line([(x + 10, 22), (x - 10, 104)], "#8A9A8C", 0.8)
    save(a, "zoo_fence")


def pool():
    """The penguin pool, a flat ground picture 700 x 320: blue water with a stone rim and a little ice."""
    from paint import np, rgb
    a = Art(700, 320, below=0)
    g = a.grid(-350, 0, 350, 320)
    X, Y, box = g
    d = ((X / 350) ** 2 + ((Y - 160) / 160) ** 2)
    rim = (d < 1) & (d > 0.78)
    water = d <= 0.78
    col = np.zeros(X.shape + (3,), np.float32)
    stone = np.array(rgb("#B8B4AA"), np.float32) * (0.85 + 0.2 * (Y / 320))[..., None]
    deep = 1 - np.clip(d / 0.78, 0, 1)
    wat = np.array(rgb("#7CC8E0"), np.float32) * (1 - deep[..., None] * 0.3) + np.array(rgb("#3A86B0"), np.float32) * (deep[..., None] * 0.3)
    wav = 0.94 + 0.08 * np.sin(Y / 9 + np.sin(X / 40) * 2)
    import paint
    if paint.FLAT:                                         # flat: one stone colour, two water colours
        stone = np.broadcast_to(np.array(rgb("#B8B4AA"), np.float32), X.shape + (3,))
        wat = np.where((d < 0.35)[..., None], np.array(rgb("#5FA8CC"), np.float32), np.array(rgb("#7CC8E0"), np.float32))
        wav = np.ones_like(X)
    col[rim] = stone[rim]
    col[water] = (wat * wav[..., None])[water]
    alpha = np.clip((1 - d) * 60, 0, 1)
    a.put(box, col, alpha)
    a.ball(-180, 200, 70, 30, "#EEF6FA", tex=0.03, spec=0.2, flat=0.7)   # an ice floe
    save(a, "pool")


def booth():
    """The ticket booth at the zoo's crossroads."""
    a = Art(260, 300)
    a.shadow(0, 2, 120, 16)
    a.poly([(-100, 0), (100, 0), (100, 190), (-100, 190)], "#F4EEDC", tex=0.06, normal=(0, 0, 1))
    a.poly([(-70, 90), (70, 90), (70, 160), (-70, 160)], "#7FA7C2", tex=0, grad=0.4)
    a.poly([(-80, 80), (80, 80), (84, 92), (-84, 92)], WOOD, tex=0.1)
    for k in range(6):                                                   # striped roof
        x0 = -120 + k * 40
        c = "#3E8E4E" if k % 2 == 0 else "#F4EEDC"
        a.poly([(x0, 190), (x0 + 40, 190), (x0 + 30, 250), (x0 + 10, 250)], c, tex=0.04, grad=0.4, normal=(0, 0.6, 1))
    a.poly([(-120, 250), (120, 250), (0, 290)], "#3E8E4E", tex=0.05, normal=(0, 0.6, 1))
    a.poly([(-70, 20), (70, 20), (70, 62), (-70, 62)], WOOD_LIGHT, tex=0.1)
    a.text("TICKETS", 0, 41, 24, "#3E5A40")
    save(a, "ticket_booth")


def sign(name, words):
    a = Art(210, 170)
    a.shadow(0, 2, 40, 8)
    a.cylinder(-7, 0, 7, 120, WOOD_DARK, bark=True)
    a.poly([(-96, 80), (96, 80), (96, 150), (-96, 150)], "#3E5A40", tex=0.08, grad=0.3, normal=(0, 0.1, 1))
    a.poly([(-88, 86), (88, 86), (88, 144), (-88, 144)], "#F4EEDC", tex=0.05, grad=0.2)
    a.text(words, 0, 115, 26, "#3E5A40", max_w=160, engrave=False)
    save(a, name)


if __name__ == "__main__":
    lion()
    giraffe()
    penguin()
    elephant()
    fence()
    pool()
    booth()
    sign("sign_lions", "LIONS")
    sign("sign_giraffes", "GIRAFFES")
    sign("sign_penguins", "PENGUINS")
    sign("sign_elephants", "ELEPHANTS")
    print("pictures in", OUT)
