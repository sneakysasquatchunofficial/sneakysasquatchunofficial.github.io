"""A small painting kit for SSMod art that looks 3D: shapes are lit like solid objects (balls, cylinders, cones and
flat facets lit from the upper left), with texture noise, darker edges, highlights and soft shadows.

    art = Art(200, 400)                 # a picture 200 x 400 world units, (0, 0) = bottom centre, +y up
    art.shadow(0, 0, 80, 14)
    art.cylinder(-10, 0, 10, 120, BARK, bark=True)
    art.ball(0, 260, 90, 80, LEAF)
    art.save("tree.png")                # 1 pixel = 1 world unit

Needs numpy and Pillow (~/ssvenv/bin/python3).
"""
import math
import os

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

LIGHT = np.array([-0.55, 0.62, 0.56])
LIGHT = LIGHT / np.linalg.norm(LIGHT)
FONT = "/System/Library/Fonts/Supplemental/Arial Rounded Bold.ttf"
# FLAT: the game's own style - solid colours, a crisp darker side instead of smooth lighting, no texture noise, no
# highlights, no engraving. False brings back the old lit look.
FLAT = True
LIT, DARK = 1.0, 0.8                    # flat style: the lit side and the shadow side


def rgb(c):
    if isinstance(c, str):
        c = c.lstrip("#")
        return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))
    return tuple(c[:3])


def noise(w, h, seed=0, scales=((4, 0.5), (12, 0.3), (40, 0.2))):
    """Smooth value noise in 0..1, several octaves (cells across the width, weight)."""
    rnd = np.random.default_rng(seed)
    out = np.zeros((h, w), np.float32)
    for cells, wt in scales:
        cw = max(2, int(cells))
        ch = max(2, int(cells * h / max(w, 1)))
        small = Image.fromarray((rnd.random((ch, cw)) * 255).astype(np.uint8))
        out += np.asarray(small.resize((w, h), Image.BICUBIC), np.float32) / 255 * wt
    tot = sum(wt for _, wt in scales)
    return np.clip(out / tot, 0, 1)


class Art:
    def __init__(self, w, h, below=14, ss=3, seed=0):
        self.w, self.h, self.below, self.ss = w, h, below, ss
        self.W, self.H = int(w * ss), int((h + below) * ss)
        self.img = Image.new("RGBA", (self.W, self.H), (0, 0, 0, 0))
        self.seed = seed
        self._n = 0

    # ---- coordinates
    def px(self, x, y):
        return ((x + self.w / 2) * self.ss, (self.h - y) * self.ss)

    def grid(self, x0, y0, x1, y1):
        """World x, y of every pixel centre in a box, and the pixel box."""
        a, b = self.px(x0, y1)
        c, d = self.px(x1, y0)
        a, b = max(0, int(a)), max(0, int(b))
        c, d = min(self.W, int(math.ceil(c))), min(self.H, int(math.ceil(d)))
        if c <= a or d <= b:
            return None
        xs = (np.arange(a, c) + 0.5) / self.ss - self.w / 2
        ys = self.h - (np.arange(b, d) + 0.5) / self.ss
        X, Y = np.meshgrid(xs, ys)
        return X, Y, (a, b, c, d)

    def nextseed(self):
        self._n += 1
        return self.seed * 1000 + self._n

    # ---- compositing
    def put(self, box, colour, alpha):
        """colour: (h, w, 3) floats 0..255, alpha: (h, w) 0..1, into the pixel box."""
        a, b, c, d = box
        layer = np.zeros((d - b, c - a, 4), np.uint8)
        layer[..., :3] = np.clip(colour, 0, 255).astype(np.uint8)
        layer[..., 3] = np.clip(alpha * 255, 0, 255).astype(np.uint8)
        full = Image.new("RGBA", (self.W, self.H), (0, 0, 0, 0))
        full.paste(Image.fromarray(layer, "RGBA"), (a, b))
        self.img = Image.alpha_composite(self.img, full)

    def mask_of(self, draw_fn):
        m = Image.new("L", (self.W, self.H), 0)
        draw_fn(ImageDraw.Draw(m))
        return np.asarray(m, np.float32) / 255

    def put_mask(self, mask, colour_fn):
        """Paint where mask > 0; colour_fn(X, Y) gives the colour per pixel (world coords)."""
        ys, xs = np.nonzero(mask > 0.002)
        if len(xs) == 0:
            return
        a, b, c, d = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
        sub = mask[b:d, a:c]
        xw = (np.arange(a, c) + 0.5) / self.ss - self.w / 2
        yw = self.h - (np.arange(b, d) + 0.5) / self.ss
        X, Y = np.meshgrid(xw, yw)
        self.put((a, b, c, d), colour_fn(X, Y), sub)

    def texture(self, X, Y, amount, scale=1.0, seed=None):
        """Per-pixel multiplier 1 +- amount from noise, fixed to world positions."""
        if FLAT:
            return np.ones_like(X)
        if amount <= 0:
            return 1.0
        h, w = X.shape
        n = noise(w, h, seed if seed is not None else self.nextseed(),
                  scales=((max(2, w / (60 * self.ss) / scale), 0.4), (max(3, w / (14 * self.ss) / scale), 0.35),
                          (max(4, w / (4 * self.ss) / scale), 0.25)))
        return 1 + (n - 0.5) * 2 * amount

    # ---- lit shapes
    def ball(self, cx, cy, rx, ry, colour, tex=0.10, spec=0.18, rim=0.35, flat=0.0, light=LIGHT):
        """A lit blob (a squashed sphere): canopies, bushes, berries, round stones."""
        g = self.grid(cx - rx, cy - ry, cx + rx, cy + ry)
        if g is None:
            return
        X, Y, box = g
        nx, ny = (X - cx) / rx, (Y - cy) / ry
        d = nx * nx + ny * ny
        inside = d < 1
        if FLAT:                                            # two tones: a darker crescent on the lower right
            ox, oy = nx + 0.28, ny - 0.28
            lit = ox * ox + oy * oy < 1.0
            k = np.where(lit, LIT, DARK)
            col = np.array(rgb(colour), np.float32)[None, None, :] * k[..., None]
            edge = np.clip((1 - d) * min(rx, ry) * self.ss / 1.5, 0, 1)
            self.put(box, col, edge * inside)
            return
        nz = np.sqrt(np.clip(1 - d, 0, 1))
        nz2 = nz * (1 - flat) + flat
        dot = np.clip(nx * light[0] + ny * light[1] + nz2 * light[2], 0, 1)
        shade = 0.42 + 0.72 * dot
        shade *= 1 - rim * (1 - nz) ** 2
        refl = np.clip(2 * dot * nz2 - light[2], 0, 1) ** 14 * spec
        base = np.array(rgb(colour), np.float32)
        t = self.texture(X, Y, tex)
        col = base[None, None, :] * (shade * t)[..., None] + 255 * refl[..., None]
        edge = np.clip((1 - d) * min(rx, ry) * self.ss / 1.5, 0, 1)      # anti-aliased rim
        self.put(box, col, edge * inside)

    def cylinder(self, x0, y0, x1, y1, colour, tex=0.12, bark=False, top=None):
        """An upright cylinder seen from the front (trunks, posts, poles): lit across its width."""
        g = self.grid(x0, y0, x1, y1)
        if g is None:
            return
        X, Y, box = g
        u = (X - (x0 + x1) / 2) / ((x1 - x0) / 2)
        if FLAT:                                            # a lighter strip on the left, darker on the right
            k = np.where(u < -0.45, 1.1, np.where(u > 0.45, DARK, LIT))
            self.put(box, np.array(rgb(colour), np.float32)[None, None, :] * k[..., None], np.ones_like(X))
            if top:
                self.ball((x0 + x1) / 2, y1, (x1 - x0) / 2, (x1 - x0) / 6, top, tex=0.05, spec=0.05, rim=0.1, flat=0.8)
            return
        nz = np.sqrt(np.clip(1 - u * u, 0, 1))
        dot = np.clip(u * LIGHT[0] + nz * (LIGHT[2] + 0.3), 0, 1.2)
        shade = 0.45 + 0.6 * dot
        base = np.array(rgb(colour), np.float32)
        t = self.texture(X, Y, tex)
        if bark:                                            # vertical grain
            h, w = X.shape
            streaks = noise(w, max(2, h // 8), self.nextseed(), scales=((w / (3 * self.ss), 1.0),))
            streaks = np.asarray(Image.fromarray((streaks * 255).astype(np.uint8)).resize((w, h)), np.float32) / 255
            t = t * (0.82 + 0.3 * streaks)
        col = base[None, None, :] * (shade * t)[..., None]
        self.put(box, col, np.ones_like(X))
        if top:                                             # a cut top (stumps, logs, posts)
            self.ball((x0 + x1) / 2, y1, (x1 - x0) / 2, (x1 - x0) / 6, top, tex=0.05, spec=0.05, rim=0.1, flat=0.8)

    def poly(self, pts, colour, tex=0.08, grad=0.25, normal=None, aa=True):
        """A flat facet. normal: (nx, ny, nz) to light it as a tilted face; grad: lighter at the top."""
        m = self.mask_of(lambda dr: dr.polygon([self.px(x, y) for x, y in pts], fill=255))
        ys = [y for _, y in pts]
        y0, y1 = min(ys), max(ys)
        base = np.array(rgb(colour), np.float32)
        k = 1.0
        if normal is not None:
            n = np.array(normal, np.float32)
            n = n / np.linalg.norm(n)
            k = 0.45 + 0.7 * max(0.0, float(n @ LIGHT))

        if FLAT:
            grad = 0.0
            k = 1.0 if normal is None else (LIT if k >= 0.75 else DARK if k < 0.6 else 0.9)

        def col(X, Y):
            g = 1 - grad / 2 + grad * (Y - y0) / max(y1 - y0, 1e-3)
            return base[None, None, :] * (k * g * self.texture(X, Y, tex))[..., None]
        self.put_mask(m, col)

    def cone(self, apex, left, right, colour, tex=0.12, teeth=0, seed=0):
        """A lit cone seen from the side (a fir's tier): lighter on the left, with a ragged lower edge."""
        ax, ay = apex
        (lx, ly), (rx, ry) = left, right
        rnd = np.random.default_rng(seed)
        pts = [apex, left]
        if teeth:
            for i in range(1, teeth * 2):
                t = i / (teeth * 2)
                x = lx + (rx - lx) * t
                y = ly + (ry - ly) * t - (rnd.uniform(6, 13) if i % 2 else rnd.uniform(-2, 3))
                pts.append((x, y))
        pts.append(right)
        m = self.mask_of(lambda dr: dr.polygon([self.px(x, y) for x, y in pts], fill=255))
        base = np.array(rgb(colour), np.float32)

        if FLAT:                                            # lit left half, shadowed right half
            self.put_mask(m, lambda X, Y: base[None, None, :] * np.where(X < ax, LIT, DARK)[..., None])
            return

        def col(X, Y):
            half = np.maximum((ay - Y) / max(ay - ly, 1) * (rx - lx) / 2, 1)
            u = np.clip((X - ax) / half, -1, 1)
            nz = np.sqrt(np.clip(1 - u * u, 0, 1))
            dot = np.clip(u * LIGHT[0] + 0.35 * LIGHT[1] + nz * LIGHT[2], 0, 1)
            v = np.clip((Y - ly) / max(ay - ly, 1), 0, 1)
            shade = (0.38 + 0.75 * dot) * (0.82 + 0.25 * v)
            return base[None, None, :] * (shade * self.texture(X, Y, tex, scale=0.6))[..., None]
        self.put_mask(m, col)

    def facets(self, outline, peak, colour, tex=0.06):
        """A low-poly solid (rocks): triangles from each outline edge up to a peak, each lit by its own normal."""
        px_, py_, pz = peak
        for (x0, y0), (x1, y1) in zip(outline, outline[1:] + outline[:1]):
            a = np.array([x0 - px_, y0 - py_, -pz])
            b = np.array([x1 - px_, y1 - py_, -pz])
            n = np.cross(a, b)
            if n[2] < 0:
                n = -n
            self.poly([(px_, py_), (x0, y0), (x1, y1)], colour, tex=tex, grad=0.0, normal=tuple(n))

    def shadow(self, cx, cy, rx, ry, alpha=0.32, blur=5):
        if FLAT:
            blur, alpha = 0.6, 0.22                         # a crisp, light flat shadow
        m = self.mask_of(lambda dr: dr.ellipse([*self.px(cx - rx, cy + ry), *self.px(cx + rx, cy - ry)], fill=255))
        m = np.asarray(Image.fromarray((m * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(blur * self.ss)),
                       np.float32) / 255
        self.put((0, 0, self.W, self.H), np.full((self.H, self.W, 3), (18, 34, 18), np.float32), m * alpha)

    def line(self, pts, colour, width):
        m = self.mask_of(lambda dr: dr.line([self.px(x, y) for x, y in pts], fill=255, width=int(width * self.ss),
                                            joint="curve"))
        base = np.array(rgb(colour), np.float32)
        self.put_mask(m, lambda X, Y: base[None, None, :] * self.texture(X, Y, 0.1)[..., None])

    def text(self, words, cx, cy, size, colour, max_w=None, engrave=True, font=FONT):
        """Words painted on (cut into a board: a darker line under, a light line over)."""
        sz = size * self.ss
        f = ImageFont.truetype(font, int(sz))
        if max_w:
            while f.getlength(words) > max_w * self.ss and sz > 6:
                sz *= 0.94
                f = ImageFont.truetype(font, int(sz))
        x, y = self.px(cx, cy)
        layer = Image.new("RGBA", (self.W, self.H), (0, 0, 0, 0))
        d = ImageDraw.Draw(layer)
        c = rgb(colour)
        if engrave and not FLAT:
            d.text((x, y + 1.2 * self.ss), words, font=f, anchor="mm", fill=(255, 240, 210, 120))
        d.text((x, y), words, font=f, anchor="mm", fill=c + (255,))
        self.img = Image.alpha_composite(self.img, layer)

    def save(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        out = self.img.resize((self.w, self.h + self.below), Image.LANCZOS)
        out.save(path)
        return out
