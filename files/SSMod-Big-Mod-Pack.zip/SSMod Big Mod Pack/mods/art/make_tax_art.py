"""Art for mods/taxes.ssmod in the game's own flat style (like the Town Hall): solid colours, no texture or gradients,
darker bands for ledges and undersides, a dark plaque with a gold border for the sign.

  ~/ssvenv/bin/python3 mods/art/make_tax_art.py
"""
import os

from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "tax")
FONT = "/System/Library/Fonts/Supplemental/Arial Rounded Bold.ttf"
SS = 3                                    # drawn 3x bigger, then scaled down (smooth edges)
BELOW = 14                                # room under the ground point (same as the trail art)

# the Town Hall's colours
STONE = "#B3ABA0"
STONE_LIGHT = "#C9C1B5"
STONE_DARK = "#9A928A"
PLAQUE = "#4A4A4A"
GOLD = "#E8B84A"
GOLD_DARK = "#C9962E"
HEDGE = "#3A8A35"
HEDGE_DARK = "#2F7A2C"
POT = "#B8643E"
POT_DARK = "#97502F"


class Flat:
    """(0, 0) = bottom centre, +y up, 1 unit = 1 pixel in the game."""

    def __init__(self, w, h, below=BELOW):
        self.w, self.h, self.below = w, h, below
        self.img = Image.new("RGBA", (w * SS, (h + below) * SS), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.img)

    def p(self, x, y):
        return ((x + self.w / 2) * SS, (self.h - y) * SS)

    def rect(self, x0, y0, x1, y1, c, r=0):
        a, b = self.p(x0, y1)
        c_, d = self.p(x1, y0)
        if r:
            self.d.rounded_rectangle([a, b, c_, d], r * SS, fill=c)
        else:
            self.d.rectangle([a, b, c_, d], fill=c)

    def poly(self, pts, c):
        self.d.polygon([self.p(x, y) for x, y in pts], fill=c)

    def circle(self, x, y, r, c):
        self.d.ellipse([*self.p(x - r, y + r), *self.p(x + r, y - r)], fill=c)

    def text(self, words, x, y, size, c, max_w=None):
        f = ImageFont.truetype(FONT, int(size * SS))
        while max_w and f.getlength(words) > max_w * SS and size > 6:
            size *= 0.94
            f = ImageFont.truetype(FONT, int(size * SS))
        self.d.text(self.p(x, y), words, font=f, anchor="mm", fill=c)

    def shadow(self, x, y, rx, ry):
        self.d.ellipse([*self.p(x - rx, y + ry), *self.p(x + rx, y - ry)], fill=(0, 0, 0, 50))

    def save(self, name):
        os.makedirs(OUT, exist_ok=True)
        self.img.resize((self.w, self.h + self.below), Image.LANCZOS).save(os.path.join(OUT, name + ".png"))


def coin(a, x, y, r):
    a.circle(x, y, r, GOLD_DARK)
    a.circle(x, y, r * 0.8, GOLD)
    a.text("$", x, y, r * 1.1, GOLD_DARK)


def arch():
    """Two square stone pillars, a beam with the TAX OFFICE plaque, a hedge box at each pillar's foot."""
    a = Flat(440, 320)
    for x in (-140, 140):
        a.shadow(x, 0, 40, 7)
        a.rect(x - 34, 0, x + 34, 22, STONE_DARK)            # the base
        a.rect(x - 28, 22, x + 28, 236, STONE)               # the pillar
        a.rect(x - 28, 22, x - 14, 236, STONE_LIGHT)         # its lit side
        a.rect(x - 34, 236, x + 34, 250, STONE_DARK)         # the cap
    a.rect(-180, 250, 180, 300, STONE)                       # the beam
    a.rect(-180, 290, 180, 300, STONE_LIGHT)                 # its top edge
    a.rect(-180, 250, 180, 258, STONE_DARK)                  # its underside
    a.rect(-118, 256, 118, 292, GOLD)                        # the plaque (like the Town Hall's)
    a.rect(-112, 262, 112, 286, PLAQUE)
    a.text("TAX OFFICE", 0, 274, 19, GOLD, max_w=200)
    coin(a, 0, 304, 13)
    for x in (-140, 140):                                    # hedge boxes beside the pillars
        side = -1 if x < 0 else 1
        hx = x + side * 52
        a.rect(hx - 16, 0, hx + 16, 18, POT_DARK)
        a.rect(hx - 16, 6, hx + 16, 18, POT)
        a.rect(hx - 18, 18, hx + 18, 44, HEDGE, r=6)
        a.rect(hx - 18, 18, hx + 18, 26, HEDGE_DARK)
    a.save("tax_arch")


def poster(name, lines, bg, fg, with_coin=True):
    a = Flat(150, 190, below=0)
    a.rect(-72, 0, 72, 190, "#5E5E5E")                      # the frame
    a.rect(-66, 6, 66, 184, bg)
    y = 160
    for words, size in lines:
        a.text(words, 0, y, size, fg, max_w=120)
        y -= size + 10
    if with_coin:
        coin(a, 0, 46, 26)
    a.save(name)


def main():
    arch()
    poster("poster_ontime", [("PAY ON", 24), ("TIME!", 24)], "#F2C14E", "#3A3A3A")
    poster("poster_days", [("TAX DAY", 20), ("EVERY", 16), ("3 DAYS", 22)], "#8FB8CA", "#3A3A3A")
    poster("poster_late", [("LATE?", 26), ("FEE GOES", 15), ("UP 5%", 22)], "#D9704F", "#FFFFFF", with_coin=False)
    print("wrote", sorted(os.listdir(OUT)))


if __name__ == "__main__":
    main()
