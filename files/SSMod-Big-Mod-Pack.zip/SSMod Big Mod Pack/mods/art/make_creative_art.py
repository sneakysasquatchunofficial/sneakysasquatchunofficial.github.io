"""The Creative book: flat colours, no shading, like the game's own art. Writes art/creative/."""
import os
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "creative")
COVER, EDGE, PAGE, LINE, RIBBON = "#7A4A25", "#5A3A1E", "#F4E8CF", "#E3D3B2", "#C8423B"


def book_open():
    w, h, s = 390, 250, 4
    im = Image.new("RGBA", (w * s, h * s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, w * s - 1, h * s - 1), 10 * s, fill=COVER)
    d.rounded_rectangle((7 * s, 7 * s, w * s // 2 - s, (h - 7) * s), 5 * s, fill=PAGE)
    d.rounded_rectangle((w * s // 2 + s, 7 * s, (w - 7) * s, (h - 7) * s), 5 * s, fill=PAGE)
    d.rectangle((w * s // 2 - s, 0, w * s // 2 + s, h * s), fill=EDGE)
    d.rectangle((16 * s, 52 * s, (w - 16) * s, 53 * s), fill=LINE)
    d.polygon([((w - 34) * s, (h - 1) * s), ((w - 34) * s, (h - 22) * s), ((w - 27) * s, (h - 15) * s),
               ((w - 20) * s, (h - 22) * s), ((w - 20) * s, (h - 1) * s)], fill=RIBBON)
    im.resize((w, h), Image.LANCZOS).save(os.path.join(OUT, "book_open.png"))


def book_icon():
    n, s = 56, 4
    im = Image.new("RGBA", (n * s, n * s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((8 * s, 4 * s, 48 * s, 52 * s), 5 * s, fill=COVER)
    d.rectangle((8 * s, 4 * s, 15 * s, 52 * s), fill=EDGE)
    d.rectangle((16 * s, 44 * s, 47 * s, 48 * s), fill=PAGE)
    d.rounded_rectangle((22 * s, 12 * s, 42 * s, 28 * s), 2 * s, fill=PAGE)
    d.rectangle((26 * s, 17 * s, 38 * s, 18 * s), fill=LINE)
    d.rectangle((26 * s, 22 * s, 38 * s, 23 * s), fill=LINE)
    d.polygon([(38 * s, 44 * s), (38 * s, 55 * s), (41 * s, 52 * s), (44 * s, 55 * s), (44 * s, 44 * s)], fill=RIBBON)
    im.resize((n, n), Image.LANCZOS).save(os.path.join(OUT, "book_icon.png"))


def slider():
    Image.new("RGBA", (300, 7), EDGE).save(os.path.join(OUT, "slider_bar.png"))
    im = Image.new("RGBA", (14, 22), (0, 0, 0, 0))
    ImageDraw.Draw(im).rounded_rectangle((0, 0, 13, 21), 4, fill=RIBBON)
    im.save(os.path.join(OUT, "slider_knob.png"))


book_open()
book_icon()
slider()
Image.new("RGBA", (2, 2), (0, 0, 0, 0)).save(os.path.join(OUT, "blank.png"))
