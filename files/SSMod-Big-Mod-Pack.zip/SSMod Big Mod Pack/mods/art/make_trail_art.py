"""Draws the art for the trails (mods/trails.ssmod) and the mods at their ends, lit to look solid (paint.py): trees,
bushes, rocks, flowers, benches, the shop stall, the hot dog cart, the lab, the finish arch, the wizard's tower,
the ranger's lookout and the fan club board. 1 pixel = 1 world unit; every picture has 14 units of room under its
ground point for its shadow (so place it 14 lower than where it stands).
  ~/ssvenv/bin/python3 mods/art/make_trail_art.py
"""
import math
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paint import Art  # noqa: E402

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "trail")
BARK, BIRCH = "#7A5436", "#ECE7DC"
WOOD, WOOD_DARK, WOOD_LIGHT = "#B07C48", "#80582F", "#D0A06A"
STONE = "#9A9CA4"


def save(art, name):
    art.save(os.path.join(OUT, name + ".png"))


# ---------------------------------------------------------------- trees
def pine(name, h, w, green, seed):
    rnd = random.Random(seed)
    a = Art(w + 30, h, seed=seed)
    a.shadow(8, 2, w * 0.42, 16)
    a.cylinder(-11, 0, 11, h * 0.34, BARK, bark=True)
    tiers = 5
    for k in range(tiers):
        t = k / (tiers - 1)
        bottom = h * (0.15 + 0.165 * k)
        top = min(h, bottom + h * (0.36 - 0.035 * k))
        half = w / 2 * (1 - 0.7 * t) * rnd.uniform(0.94, 1.04)
        sh = [int(c * (0.82 + 0.08 * k)) for c in bytes.fromhex(green[1:])]
        a.cone((rnd.uniform(-3, 3), top), (-half, bottom + 4), (half, bottom - 2), "#%02x%02x%02x" % tuple(min(255, c) for c in sh),
               teeth=5, seed=seed * 10 + k)
    save(a, name)


def leafy(name, h, w, green, trunk=BARK, seed=1, fruit=None, birch=False):
    rnd = random.Random(seed)
    a = Art(w + 60, int(h * 1.12), seed=seed)
    a.shadow(10, 2, w * 0.45, 17)
    a.cylinder(-12, 0, 12, h * 0.5, trunk, bark=not birch, tex=0.08 if birch else 0.14)
    if birch:                                       # dark marks on the white bark
        for _ in range(9):
            y = rnd.uniform(10, h * 0.48)
            a.line([(rnd.uniform(-9, -2), y), (rnd.uniform(2, 9), y + rnd.uniform(-2, 2))], "#3A3530", 2.2)
    a.line([(0, h * 0.4), (-w * 0.2, h * 0.57)], trunk, 8)
    a.line([(2, h * 0.36), (w * 0.22, h * 0.52)], trunk, 7)
    cy = h * 0.67
    blobs = []
    for i in range(11):
        ang = rnd.uniform(0, 2 * math.pi)
        r = rnd.uniform(0, 1) ** 0.6
        blobs.append((math.cos(ang) * r * w * 0.3, cy + math.sin(ang) * r * h * 0.17, rnd.uniform(0.2, 0.27) * w))
    blobs.sort(key=lambda b: -b[1] + b[0] * 0.3)       # back (high, right) first
    g = bytes.fromhex(green[1:])
    for bx, by, r in blobs:
        k = 0.85 + 0.25 * (by - cy + h * 0.2) / (h * 0.4) - 0.1 * (bx / w)
        c = "#%02x%02x%02x" % tuple(min(255, int(v * k)) for v in g)
        a.ball(bx, by, r, r * 0.88, c, tex=0.16, spec=0.08)
    if fruit:
        for _ in range(12):
            bx, by, r = rnd.choice(blobs)
            fx, fy = bx + rnd.uniform(-r, r) * 0.6, by + rnd.uniform(-r, r) * 0.5
            a.ball(fx, fy, 7, 7, fruit, tex=0.02, spec=0.6, rim=0.2)
    save(a, name)


def bush(name, w, h, green, flower=None, seed=3):
    rnd = random.Random(seed)
    a = Art(w + 20, h, seed=seed)
    a.shadow(4, 2, w * 0.5, 13)
    g = bytes.fromhex(green[1:])
    blobs = sorted([(rnd.uniform(-w * 0.28, w * 0.28), rnd.uniform(h * 0.38, h * 0.6), rnd.uniform(0.26, 0.34) * w)
                    for _ in range(7)], key=lambda b: -b[1])
    for bx, by, r in blobs:
        k = 0.9 + 0.2 * (by / h)
        c = "#%02x%02x%02x" % tuple(min(255, int(v * k)) for v in g)
        a.ball(bx, by, r, min(r * 0.8, by), c, tex=0.18, spec=0.06)
    if flower:
        for _ in range(11):
            bx, by, r = rnd.choice(blobs)
            fx, fy = bx + rnd.uniform(-0.6, 0.6) * r, by + rnd.uniform(-0.2, 0.6) * r
            a.ball(fx, fy, 5, 5, flower, tex=0, spec=0.3, rim=0.2)
            a.ball(fx - 1, fy + 1, 2, 2, "#FFF4D6", tex=0, spec=0, rim=0)
    save(a, name)


def rock(name, w, h, seed):
    rnd = random.Random(seed)
    a = Art(w + 16, h, below=10, seed=seed)
    a.shadow(6, 3, w * 0.55, 10)
    n = 9
    outline = []
    for i in range(n):
        ang = math.pi * i / (n - 1)
        r = rnd.uniform(0.8, 1.0)
        outline.append((-math.cos(ang) * w / 2 * r, math.sin(ang) * h * r * 0.95))
    outline = [(-w / 2 * 0.95, 0)] + outline + [(w / 2 * 0.95, 0)]
    a.facets(outline, (-w * 0.08, h * 0.55, h * 0.9), STONE)
    a.ball(-w * 0.12, h * 0.72, w * 0.14, h * 0.06, "#6E9A4A", tex=0.25, spec=0, flat=0.6)   # a little moss
    save(a, name)


def flowers(name, cols, seed):
    rnd = random.Random(seed)
    a = Art(100, 46, below=6, seed=seed)
    a.shadow(0, 2, 40, 6, alpha=0.2, blur=3)
    for _ in range(11):
        x = rnd.uniform(-40, 40)
        top = rnd.uniform(16, 38)
        a.line([(x, 0), (x + rnd.uniform(-4, 4), top)], "#4E8A42", 2.2)
        a.ball(x + 4, top * 0.4, 5, 2.4, "#5E9C4E", tex=0, spec=0)
        c = rnd.choice(cols)
        for k in range(5):
            ang = 2 * math.pi * k / 5 + rnd.uniform(0, 1)
            a.ball(x + math.cos(ang) * 4.2, top + math.sin(ang) * 4.2, 3.6, 3.6, c, tex=0, spec=0.2, rim=0.25)
        a.ball(x, top, 2.4, 2.4, "#FFCF4A", tex=0, spec=0.3)
    save(a, name)


def grass(name, seed):
    rnd = random.Random(seed)
    a = Art(70, 34, below=4, seed=seed)
    for _ in range(18):
        x = rnd.uniform(-28, 28)
        h = rnd.uniform(12, 30)
        c = rnd.choice(["#5E9E4A", "#78B45C", "#4C8A3E"])
        a.poly([(x - 3, 0), (x + 3, 0), (x + rnd.uniform(-9, 9), h)], c, tex=0.05, grad=0.5)
    save(a, name)


def mushrooms(name):
    a = Art(64, 44, below=6)
    a.shadow(0, 2, 26, 6)
    for x, h, r in ((-12, 22, 11), (8, 16, 9), (20, 10, 6)):
        a.cylinder(x - 3, 0, x + 3, h, "#F0E8D6", tex=0.03)
        a.ball(x, h, r, r * 0.62, "#D0443A", tex=0.04, spec=0.4)
        for dx, dy in ((-0.4, 0.3), (0.3, 0.2), (0, 0.45)):
            a.ball(x + dx * r, h + dy * r, 1.6, 1.4, "#FFF6E8", tex=0, spec=0, rim=0)
    save(a, name)


def stump(name):
    a = Art(84, 50, below=8)
    a.shadow(4, 2, 40, 9)
    a.cylinder(-28, 0, 28, 34, BARK, bark=True, top="#D6AC78")
    a.ball(0, 34, 16, 5, "#C29560", tex=0.02, spec=0, rim=0.1, flat=0.9)
    save(a, name)


def log_bench(name):
    a = Art(190, 62, below=8)
    a.shadow(0, 2, 90, 10)
    # a lying log: lit like a cylinder turned on its side
    from paint import np, rgb
    g = a.grid(-80, 0, 80, 40)
    X, Y, box = g
    v = (Y - 20) / 20
    nz = np.sqrt(np.clip(1 - v * v, 0, 1))
    shade = 0.45 + 0.6 * np.clip(v * 0.62 + nz * 0.56, 0, 1.2)
    import paint
    if paint.FLAT:
        shade = np.where(v > -0.35, paint.LIT, paint.DARK)    # flat: a darker underside
    base = np.array(rgb(BARK), np.float32)
    a.put(box, base[None, None, :] * (shade * a.texture(X, Y, 0.18))[..., None], np.ones_like(X))
    a.ball(-80, 20, 11, 20, "#D6AC78", tex=0.03, spec=0, rim=0.15, flat=0.85)
    a.ball(-80, 20, 5, 9, "#B88A56", tex=0, spec=0, rim=0, flat=1)
    save(a, name)


def lamp(name):
    a = Art(54, 190, below=6)
    a.shadow(0, 2, 16, 5)
    a.cylinder(-4, 0, 4, 150, "#4A4C56", tex=0.03)
    a.poly([(-17, 150), (17, 150), (12, 180), (-12, 180)], "#4A4C56", normal=(0, 0.3, 1))
    a.ball(0, 165, 10, 11, "#FFE29A", tex=0, spec=0.6, rim=0.05)
    save(a, name)


# ---------------------------------------------------------------- signs and props for the mods
def board(a, x0, y0, x1, y1, words, size, colour="#5B3A29", wood=WOOD):
    a.poly([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], wood, tex=0.14, grad=0.3, normal=(0, 0.1, 1))
    for y in (y0 + (y1 - y0) / 3, y0 + 2 * (y1 - y0) / 3):
        a.line([(x0 + 3, y), (x1 - 3, y)], WOOD_DARK, 1.2)
    a.poly([(x0, y0), (x1, y0), (x1, y0 + 5), (x0, y0 + 5)], WOOD_DARK, tex=0.05)
    if words:
        a.text(words, (x0 + x1) / 2, (y0 + y1) / 2, size, colour, max_w=(x1 - x0) - 18)


def shop_stall(name):
    """Corner Shop: a counter with crates and a striped awning on two posts (the keeper stands behind it)."""
    a = Art(440, 330)
    a.shadow(0, 2, 210, 22)
    for x in (-190, 190):
        a.cylinder(x - 8, 0, x + 8, 270, WOOD_DARK, bark=True)
    a.poly([(-180, 0), (180, 0), (180, 90), (-180, 90)], WOOD, tex=0.16, normal=(0, -0.2, 1))
    a.poly([(-190, 90), (190, 90), (196, 106), (-196, 106)], WOOD_LIGHT, tex=0.08, normal=(0, 1, 0.4))
    for k in range(6):
        a.line([(-180 + k * 72, 4), (-180 + k * 72, 88)], WOOD_DARK, 1.5)
    board(a, -120, 30, 120, 76, "CORNER SHOP", 26, "#B5232A", wood=WOOD_LIGHT)
    # goods on the counter
    for x, c in ((-150, "#E63946"), (-122, "#F4A261"), (-94, "#E63946"), (120, "#2A9D8F"), (148, "#E9C46A")):
        a.cylinder(x - 10, 106, x + 10, 140, c, tex=0.03)            # jars with lids
        a.cylinder(x - 11, 140, x + 11, 147, "#E9ECEF", tex=0, top="#FFFFFF")
    a.poly([(-60, 106), (-10, 106), (-10, 140), (-60, 140)], "#8D5524", tex=0.15, normal=(0, 0, 1))
    # awning: red and white stripes, scalloped edge
    for k in range(10):
        x0 = -210 + k * 42
        c = "#D62828" if k % 2 == 0 else "#F7F3EA"
        a.poly([(x0, 250), (x0 + 42, 250), (x0 + 38, 312), (x0 + 4, 312)], c, tex=0.05, grad=0.4, normal=(0, 0.6, 1))
        a.poly([(x0 + 21 + 21 * math.cos(t), 250 - 13 * math.sin(t)) for t in [math.pi * k / 12 for k in range(13)]],
               c, tex=0.03, grad=0.5)                  # the scalloped edge
    save(a, name)


def hotdog_cart(name):
    a = Art(380, 330)
    a.shadow(0, 2, 170, 20)
    a.poly([(-150, 30), (150, 30), (150, 120), (-150, 120)], "#E8E2D0", tex=0.05, normal=(0, -0.1, 1))
    a.poly([(-150, 120), (150, 120), (158, 134), (-158, 134)], "#C9C3B3", tex=0.04, normal=(0, 1, 0.5))
    a.poly([(-150, 30), (150, 30), (150, 48), (-150, 48)], "#D62828", tex=0.05)
    board(a, -95, 58, 95, 108, "HOT DOGS", 28, "#D62828", wood="#FFD166")
    for x in (-110, 110):                               # wheels
        a.ball(x, 28, 28, 28, "#30323A", tex=0.03, spec=0.2)
        a.ball(x, 28, 10, 10, "#9A9CA4", tex=0, spec=0.4)
    # a giant hot dog on top
    a.ball(0, 158, 70, 18, "#E9B872", tex=0.08, spec=0.2)
    a.ball(0, 166, 74, 10, "#B5452F", tex=0.05, spec=0.5)
    a.line([(-60, 172), (-40, 166), (-20, 174), (0, 166), (20, 174), (40, 166), (60, 172)], "#FFD23F", 4)
    # umbrella
    a.cylinder(-4, 134, 4, 280, "#6C6F7A", tex=0)
    for k in range(8):
        x0 = -170 + k * 42.5
        c = "#FFD166" if k % 2 == 0 else "#D62828"
        a.poly([(0, 318), (x0, 268), (x0 + 42.5, 268)], c, tex=0.04, grad=0.5, normal=(-(x0 + 21) / 170, 0.6, 1))
    save(a, name)


def finish_arch(name):
    a = Art(400, 270)
    a.shadow(0, 2, 190, 16)
    for x in (-170, 170):
        a.cylinder(x - 10, 0, x + 10, 240, "#E9ECEF", tex=0.04, top="#FFFFFF")
    # a checkered banner
    for i in range(16):
        for j in range(2):
            x0, y0 = -160 + i * 20, 200 + j * 20
            c = "#1D1D22" if (i + j) % 2 == 0 else "#F7F7F7"
            a.poly([(x0, y0), (x0 + 20, y0), (x0 + 20, y0 + 20), (x0, y0 + 20)], c, tex=0.02, grad=0.2)
    board(a, -110, 150, 110, 196, "FINISH", 32, "#1D3557", wood="#FFFFFF")
    for x, c in ((-170, "#E63946"), (170, "#2A9D8F")):
        a.poly([(x, 250), (x + 40, 238), (x, 226)], c, tex=0.03)
    save(a, name)


def start_sign(name):
    a = Art(170, 140)
    a.shadow(0, 2, 40, 8)
    a.cylinder(-6, 0, 6, 110, WOOD_DARK, bark=True)
    board(a, -76, 64, 76, 118, "START", 26, "#1D5C55", wood=WOOD_LIGHT)
    save(a, name)


def lab(name):
    """The Duck Lab: a small white lab with a round window, a door and a sign."""
    a = Art(520, 380)
    a.shadow(0, 2, 250, 24)
    a.poly([(-230, 0), (230, 0), (230, 250), (-230, 250)], "#EEF0F2", tex=0.04, grad=0.15, normal=(0, 0, 1))
    a.poly([(-230, 0), (230, 0), (230, 22), (-230, 22)], "#B9C0C8", tex=0.05)
    a.poly([(-250, 250), (250, 250), (220, 320), (-220, 320)], "#5C6B7A", tex=0.06, normal=(0, 0.8, 1))
    a.poly([(-250, 250), (250, 250), (250, 262), (-250, 262)], "#3E4955", tex=0.04)
    for x in (-150, 150):                               # round windows
        a.ball(x, 160, 44, 44, "#7FA7C2", tex=0, spec=0.7, rim=0.3)
        a.ball(x - 12, 172, 12, 10, "#D7EAF5", tex=0, spec=0, rim=0)
    a.poly([(-45, 0), (45, 0), (45, 150), (-45, 150)], "#4C6A85", tex=0.05, normal=(0, 0, 1))
    a.ball(30, 75, 5, 5, "#FFD166", tex=0, spec=0.6)
    board(a, -120, 200, 120, 244, "DUCK LAB", 30, "#2B2D42", wood="#FFFFFF")
    a.cylinder(170, 320, 180, 360, "#8D99AE", tex=0)    # an antenna, with a light
    a.ball(175, 366, 9, 9, "#E63946", tex=0, spec=0.7)
    save(a, name)


def lab_table(name):
    a = Art(300, 130)
    a.shadow(0, 2, 140, 14)
    for x in (-120, 120):
        a.cylinder(x - 6, 0, x + 6, 70, "#8D99AE", tex=0)
    a.poly([(-140, 70), (140, 70), (146, 86), (-146, 86)], "#DDE2E6", tex=0.03, normal=(0, 1, 0.5))
    for x, c in ((-90, "#7BD389"), (-40, "#F28482"), (20, "#84A9FF"), (80, "#F6BD60")):
        a.poly([(x - 10, 86), (x + 10, 86), (x + 16, 104), (x + 4, 124), (x - 4, 124), (x - 16, 104)], "#E9F5FB", tex=0, normal=(0, 0.2, 1))
        a.ball(x, 98, 14, 9, c, tex=0, spec=0.6)
    save(a, name)


def wizard_tower(name):
    a = Art(300, 460)
    a.shadow(0, 2, 140, 20)
    a.cylinder(-100, 0, 100, 280, "#9A93A8", tex=0.2)
    rnd = random.Random(7)
    for row in range(9):                                # stones
        y = 14 + row * 30
        off = 0 if row % 2 else 18
        for k in range(6):
            x = -100 + off + k * 36
            if -96 < x < 96:
                a.line([(x, y), (x, y + 26)], "#7C7590", 1.5)
        a.line([(-98, y), (98, y)], "#7C7590", 1.5)
    a.poly([(-40, 0), (40, 0), (40, 110), (0, 132), (-40, 110)], "#5B3A29", tex=0.15, normal=(0, 0, 1))
    a.ball(0, 200, 26, 30, "#FFE9A8", tex=0, spec=0.5, rim=0.4)
    a.cone((10, 450), (-130, 270), (130, 270), "#5A3E8E", tex=0.1)
    for _ in range(9):
        x, y = rnd.uniform(-70, 70), rnd.uniform(300, 400)
        if abs(x) < (450 - y) * 0.7:
            a.ball(x, y, 5, 5, "#FFD166", tex=0, spec=0.6, rim=0.1)
    save(a, name)


def lookout(name):
    """Ranger Pat's lookout: a wooden cabin on four legs with a ladder and a green roof."""
    a = Art(340, 470)
    a.shadow(0, 2, 160, 22)
    for x in (-120, -60, 60, 120):
        a.cylinder(x - 9, 0, x + 9, 270, WOOD_DARK, bark=True)
    a.line([(-110, 40), (110, 230)], WOOD_DARK, 7)
    a.line([(110, 40), (-110, 230)], WOOD_DARK, 7)
    for y in range(20, 260, 30):                        # the ladder
        a.line([(-26, y), (26, y)], WOOD, 5)
    a.cylinder(-30, 0, -24, 270, WOOD, tex=0.05)
    a.cylinder(24, 0, 30, 270, WOOD, tex=0.05)
    a.poly([(-145, 260), (145, 260), (145, 370), (-145, 370)], WOOD, tex=0.16, normal=(0, 0, 1))
    for y in range(270, 370, 18):
        a.line([(-143, y), (143, y)], WOOD_DARK, 1.3)
    a.poly([(-95, 300), (95, 300), (95, 356), (-95, 356)], "#2F3E46", tex=0.03)
    a.poly([(-160, 368), (160, 368), (110, 440), (-110, 440)], "#3E7B4F", tex=0.08, normal=(0, 0.8, 1))
    board(a, -70, 266, 70, 296, "RANGER", 18, "#F7F3EA", wood="#3E7B4F")
    save(a, name)


def fanclub_board(name):
    a = Art(340, 280)
    a.shadow(0, 2, 150, 16)
    for x in (-140, 140):
        a.cylinder(x - 9, 0, x + 9, 250, WOOD_DARK, bark=True, top=WOOD_LIGHT)
    a.poly([(-150, 90), (150, 90), (150, 240), (-150, 240)], WOOD, tex=0.15, normal=(0, 0, 1))
    a.poly([(-138, 102), (138, 102), (138, 228), (-138, 228)], "#F2B5C8", tex=0.05, grad=0.2)
    a.text("LPP", 0, 192, 48, "#C2185B", engrave=False)
    a.text("FAN CLUB", 0, 148, 30, "#5B1A33", max_w=250, engrave=False)
    a.text("join today!", 0, 116, 18, "#5B1A33", engrave=False)
    for x, y, c in ((-118, 210, "#FFD166"), (118, 208, "#84A9FF"), (-112, 122, "#7BD389")):
        a.ball(x, y, 9, 9, c, tex=0, spec=0.5)              # pins
    save(a, name)


def deck(name):
    """A wooden deck to stand the shop on (a ground picture)."""
    a = Art(460, 300, below=0)
    for k in range(12):
        y0 = k * 25
        a.poly([(-230, y0), (230, y0), (230, y0 + 24), (-230, y0 + 24)], WOOD if k % 2 else "#BE8A54", tex=0.18, grad=0.1)
        a.line([(-230, y0 + 24), (230, y0 + 24)], WOOD_DARK, 1.6)
    save(a, name)


def pad(name, w, h, colour):
    a = Art(w, h, below=0)
    a.poly([(-w / 2, 0), (w / 2, 0), (w / 2, h), (-w / 2, h)], colour, tex=0.06, grad=0.05)
    for k in range(1, int(w // 60)):
        a.line([(-w / 2 + k * 60, 0), (-w / 2 + k * 60, h)], "#B9C0C8", 1.5)
    for k in range(1, int(h // 60)):
        a.line([(-w / 2, k * 60), (w / 2, k * 60)], "#B9C0C8", 1.5)
    save(a, name)


GREEN = "#4E8A5A"
if __name__ == "__main__":
    pine("pine_a", 400, 200, "#4A8A5C", 1)
    pine("pine_b", 460, 210, "#3B7A63", 2)
    pine("pine_c", 320, 170, "#52935E", 3)
    leafy("oak", 330, 260, "#5E9E48", seed=4)
    leafy("apple", 300, 240, "#64A64C", seed=5, fruit="#D9382E")
    leafy("birch", 340, 200, "#B4BE52", trunk=BIRCH, seed=6, birch=True)
    bush("bush", 150, 90, "#5E9E48", seed=7)
    bush("bush_berry", 140, 84, "#3F7E52", flower="#7A4FC2", seed=8)
    bush("bush_flower", 130, 80, "#66A84E", flower="#F6C443", seed=9)
    rock("rock_big", 150, 80, 10)
    rock("rock_small", 70, 38, 11)
    flowers("flowers_a", ["#F06C8E", "#FAFAFA"], 12)
    flowers("flowers_b", ["#8678E6", "#FAD14E"], 13)
    grass("grass_a", 14)
    grass("grass_b", 15)
    mushrooms("mushrooms")
    stump("stump")
    log_bench("log_bench")
    lamp("lamp")
    shop_stall("shop_stall")
    hotdog_cart("hotdog_cart")
    finish_arch("finish_arch")
    start_sign("start_sign")
    lab("lab")
    lab_table("lab_table")
    wizard_tower("wizard_tower")
    lookout("lookout")
    fanclub_board("fanclub_board")
    deck("deck")
    pad("lab_pad", 600, 380, "#DCE0E4")
    print("pictures in", OUT)
